-- Per-gun adaptation of TaCZ's official default state machine.
-- Clone required tables: a cached default module is shared with other guns.
local default = require("tacz_default_state_machine")

local function clone(value, seen)
    if type(value) ~= "table" then return value end
    seen = seen or {}
    if seen[value] then return seen[value] end
    local result = {}
    seen[value] = result
    for key, item in pairs(value) do
        result[clone(key, seen)] = clone(item, seen)
    end
    return setmetatable(result, getmetatable(value))
end

local M = clone(default)

function M.gun_kick_state.transition(this, context, input)
    if input == INPUT_SHOOT then
        -- The .5 s source action is restarted by each 300 ms shot.
        -- Native runAnimation with zero transition replaces this track's
        -- runner at progress zero; idle, reload, inspect and other guns stay intact.
        local track = context:getAsSingletonTrack(this.GUN_KICK_TRACK_LINE)
        context:runAnimation("shoot", track, true, PLAY_ONCE_STOP, 0)
    end
    return nil
end

return M
