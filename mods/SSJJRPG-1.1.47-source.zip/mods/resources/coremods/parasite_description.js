var O=Java.type('org.objectweb.asm.Opcodes');
var Call=Java.type('org.objectweb.asm.tree.MethodInsnNode');
var Field=Java.type('org.objectweb.asm.tree.FieldInsnNode');
var Var=Java.type('org.objectweb.asm.tree.VarInsnNode');
var List=Java.type('org.objectweb.asm.tree.InsnList');
var BRIDGE='cn/ssjjcompat/DescriptionLines';
function description(node){
    var matches=0;
    for(var i=0;i<node.methods.size();i++){
        var method=node.methods.get(i);
        if(method.name!=='getText'||method.desc!=='()V')continue;
        var old=method.instructions.toArray();
        for(var j=0;j<old.length;j++){
            var call=old[j];
            if(!(call instanceof Call))continue;
            if(call.owner===BRIDGE&&call.name==='visible')return node;
            if(call.owner!=='java/util/List'||call.name!=='subList'||call.desc!=='(II)Ljava/util/List;')continue;
            var arguments=new List();
            arguments.add(new Var(O.ALOAD,0));
            arguments.add(new Field(O.GETFIELD,node.name,'gun','Lnet/minecraft/world/item/ItemStack;'));
            method.instructions.insertBefore(call,arguments);
            method.instructions.set(call,new Call(O.INVOKESTATIC,BRIDGE,'visible',
                '(Ljava/util/List;IILnet/minecraft/world/item/ItemStack;)Ljava/util/List;',false));
            method.maxStack+=1;
            matches++;
        }
    }
    if(matches!==1)throw new Error('SSJJRPG: unsupported gun description truncation layout: '+matches);
    return node;
}
function initializeCoreMod(){return {
    'ssjj_parasite_full_description':{
        target:{type:'CLASS',name:'com.tacz.guns.client.tooltip.ClientGunTooltip'},transformer:description
    }
};}
