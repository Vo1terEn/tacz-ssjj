# Java 源码与 ASM 制作链

这里整理了当前交付相关的真实作者源码、已知 ASM 修改器、运行时映射工具和模组专有文本。原制作链是“冻结基线二进制 + 增量编译 + 映射 + ASM 修改”。这份整理不是完整的当前源码重建，也不是可独立一键构建的 Gradle/Maven 工程。

公开发布版本以仓库根 README 和 Release 标签为准。本目录追溯的开发交付标签是 `1.1.46-muzzlestun10`，来源模组 SHA-256 为 `c3356f205a30fc966fedd2a303570a671b34fa3f2665d6888a05d45cc154e6e7`。公开发布副本可以统一版本元数据；原始和公开文件校验值及差异记录在 [source-manifest.json](source-manifest.json)。

## 阅读目录

- `src/`：按 Java 包路径保留的作者源码快照，每个当前顶层类名只选一份，不收 QA 夹具、反编译文件或已退役的死亡拦截类。
- `patches/`：实际制作链中的作者 ASM 修改器，以及最新版配件、配置和物品绘制的字节码生成脚本。较早基线依赖的修改器仍按阶段归档，不能仅凭源码目录顺序推断可重跑的完整链。
- `tools/`：命名到运行时映射、运行时链接检查等工具源码。Minecraft、Forge、TaCZ、ASM、Guava、映射文件和历史基线不随此目录分发。
- `resources/`：从当前模组提取的 coremod、模组元数据、专有数据和原有许可。枪包共有文本、素材生成器及可编辑资源由同版枪包源码部分保存；大型生成采样、模型和音频等运行资源在同版 Release 配对包中。

这里的相对链接适用于源码 ZIP 解压后的目录。在 GitHub 网页通道不能保持目录层级时，源码以保留包路径的 ZIP 提供；仓库 `mods/README.md` 给出下载位置。该通道差异不改变源码来源和构建边界。

## 来源证据的范围

当前模组共有 **292 个顶层类名**，这里都有对应名称的作者源码快照。按类名找到源码不证明当前方法体相同。

| 证据范围 | 数量 | 能说明的内容 |
| --- | ---: | --- |
| 编译产物的外部类字节与当前交付一致 | 46 | 记录的对应生产编译产物与当前外部类相同；没有据此推断全部内部类或整包可重建 |
| 编译产物只与已知 ASM 修改前的类一致 | 6 | 需要同时阅读清单列出的后续修改器，不能只编译源码快照 |
| 仅有类名匹配，当前方法体未经字节码等价核验 | 240 | 作为作者代码参考，可能早于后续编译或 ASM 修改 |

292 份中有 **208 份**继承自之前公开的作者源码归档。这些是候选快照，不是本轮重新证明的当前方法体。其余来源、阶段、原始/公开 SHA、已知补丁以及最终 class 家族的 SHA 均逐项列在清单中。部分更早的 ASM 历史还未恢复为完整确定性流程，不能凭这些文件宣称获得了完整、可复现的对应源码工程。

## 本轮实现与后续修改

| 功能 | 主要源码与修改器 |
| --- | --- |
| 枪口长条光效透视方向 | `src/cn/ssjjdimension/client/DimensionParticleEffects.java`、`DimensionParticles.java` |
| 独立红莲眩晕 | `src/cn/judgfire/BurstStun.java`、`StunState.java`、`StunInput.java`、`StunNetwork.java`；`patches/stun_state_20261109/StunCallsitePatch.java` 修改原 `DimensionField` 的两处药水调用 |
| 假死的实体状态隔离 | `patches/identity_health_fix_20261109/EntityIdentityPatch.java`，把 14 个类的 18 个实体缓存初始化改为弱引用对象身份键；字段清单在 manifest |
| 能量伤害和配件数值 | `src/cn/judgfire/EnergyScaling.java`、`src/cn/ssjjcompat/AttachmentBonusConfig.java`、`AttachmentBonusRuntime.java`，另有配件/配置 ASM 扩展 |
| 配置页面合并 | `src/cn/fusionarsenal/client/ClothSettingsScreen.java`；后台 `ArsenalConfig` 还依赖 `build_dimension_config.py` 等制作链扩展 |
| 击杀提示与完整寄生者描述 | `src/cn/ssjjcompat/CombatMessages.java`、`DescriptionLines.java`，及 `resources/coremods/combat_messages.js`、`parasite_description.js` |

例如，源码快照中部分缓存仍写着 `WeakHashMap`；最终成品初始化已由身份键修改器替换。`DimensionField.java` 是独立眩晕修改之前的作者源码；最终两处调用由 `StunCallsitePatch` 替换。不能忽略这些步骤后把单次 `javac src/` 结果当作同版模组。此前用于压制死亡入口的 `CombatDeathGuard` 和 `player_death` coremod 已退役，本目录不收录它们。

## 修改与验证

只修改来源明确的目标模块，并保留精确基线、配套资源和对应补丁。现有工具需要外部 Minecraft 1.20.1、Forge 47.4.28、TaCZ API/运行库和官方映射；涉及现有命名空间的继承 API 还需制作链基线。脚本中出现的工作区相对路径只是来源关系，不表示这些外部目录已包含在源码 ZIP 中。

本轮整理核对来源 SHA、源码选择、文本可解析性、已知补丁和最终载荷绑定，没有为这 292 份快照执行一次完整重编译。功能层面的既有离线测试与公开打包检查应分别看发布说明；没有新增完整 Minecraft 客户端、GPU 或多人实机验收。

## 许可

沿用当前模组的许可声明：**MIT（arsenal 原创代码）**；**GPL-3.0（原始 `ssjj_dark` 素材和技能代码）**；其他美术素材保留原权利。原有 GPL-3.0 全文逐字保存在 [resources/META-INF/licenses/ssjj_dark/LICENSE](resources/META-INF/licenses/ssjj_dark/LICENSE)。`src/ssjj/dark/` 相关来源必须结合该原有声明阅读，不能将其中原有代码统一改称 MIT。

源码 ZIP 附带的根 `LICENSE` 仅覆盖项目原创代码与配置，不能覆盖上述 GPL 部分或授予其他第三方素材新的许可。原模型、动画、图片、音频与其他第三方内容继续遵守各自原有许可和声明。本目录不包含 Minecraft、Forge、TaCZ 或其他依赖库的二进制、源代码和映射文件。
