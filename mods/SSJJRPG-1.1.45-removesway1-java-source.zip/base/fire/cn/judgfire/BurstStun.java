package cn.judgfire;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraftforge.registries.*;

/** Restores pre-existing NoAI and gives an immunity window after expiry/removal. */
public final class BurstStun extends MobEffect {
  public static final DeferredRegister<MobEffect> EFFECTS =
      DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, JudgmentFlame.MODID);
  public static final RegistryObject<MobEffect> STUN =
      EFFECTS.register("red_lotus_stun", BurstStun::new);
  public static final DeferredRegister<SoundEvent> SOUNDS =
      DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, JudgmentFlame.MODID);
  public static final RegistryObject<SoundEvent> SOUND =
      SOUNDS.register(
          "red_lotus_burst",
          () ->
              SoundEvent.createVariableRangeEvent(
                  new ResourceLocation(JudgmentFlame.MODID, "red_lotus_burst")));
  private static final String SAVED = "JudgfireStunOriginalNoAI";
  public static final String IMMUNE = "JudgfireStunImmuneUntil";

  private BurstStun() {
    super(MobEffectCategory.HARMFUL, 0xFF6324);
    addAttributeModifier(
        Attributes.MOVEMENT_SPEED,
        "9854618e-8aba-4a4a-a70b-c028e480ce9d",
        -1,
        AttributeModifier.Operation.MULTIPLY_TOTAL);
  }

  public static boolean stunned(LivingEntity entity) {
    return entity.hasEffect(STUN.get());
  }

  public static boolean apply(LivingEntity entity, int duration) {
    if (!BurstTiming.canStun(
        stunned(entity), entity.level().getGameTime(), entity.getPersistentData().getLong(IMMUNE)))
      return false;
    return entity.addEffect(new MobEffectInstance(STUN.get(), duration, 0, false, false, true));
  }

  @Override
  public void addAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
    super.addAttributeModifiers(entity, attributes, amplifier);
    if (!entity.level().isClientSide() && entity instanceof Mob mob) {
      var data = mob.getPersistentData();
      if (!data.contains(SAVED)) data.putBoolean(SAVED, mob.isNoAi());
      mob.setNoAi(true);
      mob.getNavigation().stop();
    }
  }

  @Override
  public void removeAttributeModifiers(
      LivingEntity entity, AttributeMap attributes, int amplifier) {
    super.removeAttributeModifiers(entity, attributes, amplifier);
    if (!entity.level().isClientSide()) {
      var data = entity.getPersistentData();
      data.putLong(IMMUNE, entity.level().getGameTime() + RedLotus.BURST_IMMUNITY.get());
      if (entity instanceof Mob mob && data.contains(SAVED)) {
        mob.setNoAi(data.getBoolean(SAVED));
        data.remove(SAVED);
      }
    }
  }

  @Override
  public boolean isDurationEffectTick(int duration, int amplifier) {
    return true;
  }

  @Override
  public void applyEffectTick(LivingEntity entity, int amplifier) {
    var velocity = entity.getDeltaMovement();
    entity.setDeltaMovement(0, Math.min(0, velocity.y), 0);
    if (entity instanceof Mob mob) mob.getNavigation().stop();
  }
}
