var O = Java.type('org.objectweb.asm.Opcodes');
var Insns = Java.type('org.objectweb.asm.tree.InsnList');
var Var = Java.type('org.objectweb.asm.tree.VarInsnNode');
var Call = Java.type('org.objectweb.asm.tree.MethodInsnNode');
var Jump = Java.type('org.objectweb.asm.tree.JumpInsnNode');
var Label = Java.type('org.objectweb.asm.tree.LabelNode');
var Insn = Java.type('org.objectweb.asm.tree.InsnNode');

function reserveSkill(node) {
    var name = node.name.endsWith('/ZoomKey') ? 'onZoomKeyPress' : 'onMeleeKeyPress';
    var found = false;
    for (var i = 0; i < node.methods.size(); i++) {
        var method = node.methods.get(i);
        if (method.name !== name || method.desc !== '(Lnet/minecraftforge/client/event/InputEvent$Key;)V') continue;
        found = true;
        var prefix = new Insns(), pass = new Label();
        prefix.add(new Var(O.ALOAD, 0));
        prefix.add(new Call(O.INVOKESTATIC, 'cn/judgfire/JudgmentSkillKey', 'reserved', method.desc.replace(')V', ')Z'), false));
        prefix.add(new Jump(O.IFEQ, pass));
        prefix.add(new Insn(O.RETURN));
        prefix.add(pass);
        method.instructions.insert(prefix);
        method.maxStack = Math.max(method.maxStack, 1);
    }
    if (!found) throw new Error('Judgment Flame: unsupported skill-key entry ' + node.name);
    return node;
}
function initializeCoreMod() {
    return {
        'judgment_zoom_skill_key': {target: {type: 'CLASS', name: 'com.tacz.guns.client.input.ZoomKey'}, transformer: reserveSkill},
        'judgment_melee_skill_key': {target: {type: 'CLASS', name: 'com.tacz.guns.client.input.MeleeKey'}, transformer: reserveSkill}
    };
}
