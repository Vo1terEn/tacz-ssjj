import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import net.minecraftforge.srgutils.IMappingFile;
import org.objectweb.asm.ClassReader;

/** Translate an actual SRG dependency into a named compile/standalone-QA API. */
public final class PrepareNamed {
    public static void main(String[] args) throws Exception {
        if (args.length != 6) throw new IllegalArgumentException("official.map merged.tsrg input.jar output.jar runtime_cp.txt report.json");
        var mapping = IMappingFile.load(Path.of(args[0]).toFile())
            .chain(IMappingFile.load(Path.of(args[1]).toFile())).reverse();
        Path input=Path.of(args[2]), output=Path.of(args[3]);
        List<Path> roots=new ArrayList<>(); roots.add(input); roots.addAll(FreshRemap.readPaths(Path.of(args[4])));
        int count=0;
        try (var repository=new FreshRemap.Repository(roots); var source=new JarFile(input.toFile())) {
            var names=new FreshRemap.InheritedNames(mapping,repository);
            Files.createDirectories(output.toAbsolutePath().getParent());
            try (var jar=new JarOutputStream(Files.newOutputStream(output))) {
                for (var entry:Collections.list(source.entries())) {
                    if (entry.isDirectory()) continue;
                    byte[] bytes;
                    try (var stream=source.getInputStream(entry)) { bytes=stream.readAllBytes(); }
                    String name=entry.getName();
                    if (name.endsWith(".class")) { bytes=FreshRemap.translate(bytes,names); name=new ClassReader(bytes).getClassName()+".class"; count++; }
                    var target=new JarEntry(name); target.setTime(0L); jar.putNextEntry(target); jar.write(bytes); jar.closeEntry();
                }
            }
            FreshRemap.report(Path.of(args[5]),Map.of("classes",count,"input",input.toString(),"output",output.toString(),
                "mapping","SRG -> official named","method_changes",names.changedMethods,"field_changes",names.changedFields));
        }
        System.out.println("PrepareNamed classes="+count+" input="+input);
    }
}
