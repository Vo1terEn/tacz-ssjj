import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;

/** Compare the actual public/protected bytecode contract of every existing class. */
public final class ApiContract {
    private static Map<String,String> api(byte[] bytes) {
        Map<String,String> result=new TreeMap<>();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public void visit(int version,int access,String name,String signature,String parent,String[] interfaces) {
                result.put("class",access+":"+signature+":"+parent+":"+Arrays.toString(interfaces));
            }
            @Override public FieldVisitor visitField(int access,String name,String desc,String signature,Object value) {
                if((access&(Opcodes.ACC_PUBLIC|Opcodes.ACC_PROTECTED))!=0)
                    result.put("field:"+name,access+":"+desc+":"+signature+":"+value);
                return null;
            }
            @Override public MethodVisitor visitMethod(int access,String name,String desc,String signature,String[] exceptions) {
                if((access&(Opcodes.ACC_PUBLIC|Opcodes.ACC_PROTECTED))!=0)
                    result.put("method:"+name+desc,access+":"+signature+":"+Arrays.toString(exceptions));
                return null;
            }
        },ClassReader.SKIP_CODE|ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        return result;
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=3)throw new IllegalArgumentException("baseline.jar candidate.jar report.json");
        Set<String> checked=new TreeSet<>();
        try(var before=new JarFile(args[0]);var after=new JarFile(args[1])) {
            for(var entry:Collections.list(before.entries()))if(entry.getName().endsWith(".class")) {
                var current=after.getJarEntry(entry.getName());
                if(current==null)throw new IllegalStateException("Removed class "+entry.getName());
                try(var a=before.getInputStream(entry);var b=after.getInputStream(current)) {
                    if(!api(a.readAllBytes()).equals(api(b.readAllBytes())))
                        throw new IllegalStateException("Changed public/protected contract "+entry.getName());
                }
                checked.add(entry.getName());
            }
        }
        FreshRemap.report(java.nio.file.Path.of(args[2]),Map.of("passed",true,"existing_classes_checked",checked.size(),"public_protected_members_unchanged",true));
    }
}
