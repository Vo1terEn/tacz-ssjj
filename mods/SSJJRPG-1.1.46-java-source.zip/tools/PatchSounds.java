import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;

/** Fail-closed patch of the two sound calls in the frozen, complete DarkClient. */
public final class PatchSounds {
    private static final String BRIDGE="cn/ssjjcompat/TaCZSounds";
    private static final String DISPLAY="com/tacz/guns/client/resource/GunDisplayInstance";
    private static final String LOCATION="net/minecraft/resources/ResourceLocation";
    private static final String ENTITY="net/minecraft/world/entity/Entity";
    private static final String RESULT="Lcom/tacz/guns/client/sound/GunSoundInstance;";
    public static void main(String[] args)throws Exception {
        if(args.length!=3)throw new IllegalArgumentException("baseline.jar output.class report.json");
        byte[] original;
        try(var jar=new JarFile(args[0])) {
            try(var input=jar.getInputStream(jar.getJarEntry("ssjj/dark/DarkClient.class"))) {original=input.readAllBytes();}
        }
        int[] counts=new int[3];
        ClassWriter writer=new ClassWriter(0);
        new ClassReader(original).accept(new ClassVisitor(Opcodes.ASM9,writer) {
            @Override public MethodVisitor visitMethod(int access,String name,String desc,String signature,String[] exceptions) {
                var target=super.visitMethod(access,name,desc,signature,exceptions);
                if(!name.equals("lambda$strike$2"))return target;
                if(!desc.equals("(ZZLnet/minecraft/client/Minecraft;L"+DISPLAY+";)V"))
                    throw new IllegalStateException("Unexpected strike descriptor: "+desc);
                counts[2]++;
                return new MethodVisitor(Opcodes.ASM9,target) {
                    @Override public void visitMethodInsn(int opcode,String owner,String name,String desc,boolean itf) {
                        if(owner.equals(DISPLAY)&&name.equals("getSounds")&&desc.equals("(Ljava/lang/String;)L"+LOCATION+";")) {
                            counts[0]++;
                            super.visitMethodInsn(Opcodes.INVOKESTATIC,BRIDGE,name,"(L"+DISPLAY+";Ljava/lang/String;)Ljava/lang/Object;",false);
                        } else if(owner.equals("com/tacz/guns/client/sound/SoundPlayManager")&&name.equals("playClientSound")
                                &&desc.equals("(L"+ENTITY+";L"+LOCATION+";FFI)"+RESULT)) {
                            counts[1]++;
                            super.visitMethodInsn(Opcodes.INVOKESTATIC,BRIDGE,name,"(L"+ENTITY+";Ljava/lang/Object;FFI)"+RESULT,false);
                        } else super.visitMethodInsn(opcode,owner,name,desc,itf);
                    }
                    @Override public void visitFrame(int type,int localCount,Object[] locals,int stackCount,Object[] stack) {
                        if(locals!=null)for(int i=0;i<localCount;i++)if(LOCATION.equals(locals[i]))locals[i]="java/lang/Object";
                        if(stack!=null)for(int i=0;i<stackCount;i++)if(LOCATION.equals(stack[i]))stack[i]="java/lang/Object";
                        super.visitFrame(type,localCount,locals,stackCount,stack);
                    }
                };
            }
        },0);
        if(!Arrays.equals(counts,new int[]{1,1,1}))throw new IllegalStateException("Unexpected sound patch matches: "+Arrays.toString(counts));
        Path output=Path.of(args[1]);Files.createDirectories(output.getParent());Files.write(output,writer.toByteArray());
        FreshRemap.report(Path.of(args[2]),Map.of("getSounds_calls",counts[0],"play_calls",counts[1],"methods_touched",counts[2],"public_signatures_unchanged",true));
    }
}
