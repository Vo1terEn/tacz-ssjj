import cn.ssjjdimension.*;
import cn.ssjjdimension.client.*;
import com.google.gson.*;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.event.common.GunReloadEvent;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.api.item.nbt.GunItemDataAccessor;
import com.tacz.guns.api.client.animation.*;
import com.tacz.guns.client.model.*;
import com.tacz.guns.client.resource.pojo.model.*;
import com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile;
import com.tacz.guns.client.resource.pojo.display.attachment.AttachmentDisplay;
import com.tacz.guns.item.*;
import com.tacz.guns.resource.CommonAssetsManager;
import com.tacz.guns.resource.network.*;
import com.tacz.guns.util.AttachmentDataUtils;
import java.lang.reflect.*;
import java.lang.Math;
import java.nio.file.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.*;
import net.minecraftforge.eventbus.api.*;
import net.minecraftforge.fml.LogicalSide;
import org.joml.*;

public final class DimensionFamilyCheck {
 static final Gson G=DimensionNativeCheck.GSON.newBuilder().registerTypeAdapter(ResourceLocation.class,(JsonDeserializer<ResourceLocation>)(j,t,c)->new ResourceLocation(j.getAsString())).create();
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static Field field(Class<?> c,String n)throws Exception{var f=c.getDeclaredField(n);f.setAccessible(true);return f;}
 static ResourceLocation id(String path){return new ResourceLocation("ssjj_dimension",path);}
 static JsonObject read(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
 public static void main(String[] args)throws Exception {
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
  net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
  var mods=net.minecraftforge.fml.ModList.of(List.of(),List.of());var load=net.minecraftforge.fml.ModList.class.getDeclaredMethod("setLoadedMods",List.class);load.setAccessible(true);load.invoke(mods,List.of());
  Path w=Path.of(args[0]),a=w.resolve("pack/assets/ssjj_dimension"),d=w.resolve("pack/data/ssjj_dimension");
  // Execute actual registration, not a direct calibration-read shortcut.
  var factory=new ClassLoaderFactory();Set<String> wrappers=new HashSet<>();
  Class<?>[] registrations={DimensionNativeHands.Resources.class,DimensionParticleEffects.Resources.class,DimensionMeshRenderer.ClientResources.class};
  for(Class<?> c:registrations)for(Method m:c.getDeclaredMethods())if(m.isAnnotationPresent(SubscribeEvent.class))check(wrappers.add(factory.getUniqueName(m)),"Listener wrapper collision");
  var cache=EventListenerHelper.class.getDeclaredMethod("getListenerListInternal",Class.class,boolean.class);cache.setAccessible(true);cache.invoke(null,RegisterClientReloadListenersEvent.class,true);cache.invoke(null,net.minecraftforge.client.event.RegisterShadersEvent.class,true);
  IEventBus bus=BusBuilder.builder().build();for(Class<?> c:registrations)bus.register(c);
  var manager=new ReloadableResourceManager(PackType.CLIENT_RESOURCES);bus.post(new RegisterClientReloadListenersEvent(manager));List<?> listeners=null;
  for(Field f:manager.getClass().getDeclaredFields())if(List.class.isAssignableFrom(f.getType())){f.setAccessible(true);listeners=(List<?>)f.get(manager);break;}
  check(listeners!=null&&listeners.size()==3,"Expected three distinct reload callbacks");
  final int[] reads={0};ResourceManager resources=(ResourceManager)Proxy.newProxyInstance(DimensionFamilyCheck.class.getClassLoader(),new Class<?>[]{ResourceManager.class},(p,m,v)->{
   var loc=(ResourceLocation)v[0];Path path=w.resolve("pack/assets").resolve(loc.getNamespace()).resolve(loc.getPath());
   if(m.getName().equals("open")){reads[0]++;return Files.newInputStream(path);}
   if(m.getName().equals("getResource"))return Files.isRegularFile(path)?Optional.of(new Object()):Optional.empty();
   throw new AssertionError("Unexpected resource call "+m);
  });
  for(Object listener:listeners)((ResourceManagerReloadListener)listener).onResourceManagerReload(resources);
  var meshes=(Map<?,?>)field(DimensionMeshRenderer.class,"profiles").get(null);var particleProfiles=(Map<?,?>)field(DimensionParticleEffects.class,"profiles").get(null);
  check(meshes.size()==12&&particleProfiles.size()==12&&reads[0]==25,"Incomplete registered reload profiles");
  var calibration=(DimensionNativeHands.Calibration)field(DimensionNativeHands.class,"calibration").get(null);check(calibration.fitted_vertical_fov_degrees==46.474140767219254,"Accepted calibration not loaded");
  Map<ResourceLocation,String> gunData=new LinkedHashMap<>(),gunIndex=new LinkedHashMap<>(),attachmentData=new LinkedHashMap<>(),attachmentIndex=new LinkedHashMap<>(),allow=new LinkedHashMap<>();
  for(String gun:DimensionScopes.GUNS){gunData.put(id(gun+"_data"),Files.readString(d.resolve("data/guns/"+gun+"_data.json")));gunIndex.put(id(gun),Files.readString(d.resolve("index/guns/"+gun+".json")));allow.put(id("allow_attachments/"+gun),Files.readString(d.resolve("tacz_tags/attachments/allow_attachments/"+gun+".json")));}
  for(String skin:DimensionScopes.SKINS){attachmentData.put(id(skin+"_scope_data"),Files.readString(d.resolve("data/attachments/"+skin+"_scope_data.json")));attachmentIndex.put(id(skin+"_scope"),Files.readString(d.resolve("index/attachments/"+skin+"_scope.json")));}
  CommonAssetsManager.clearInstance();CommonNetworkCache.INSTANCE.clear();CommonNetworkCache.INSTANCE.fromNetwork(Map.of(DataType.GUN_DATA,gunData,DataType.GUN_INDEX,gunIndex,DataType.ATTACHMENT_DATA,attachmentData,DataType.ATTACHMENT_INDEX,attachmentIndex,DataType.ATTACHMENT_TAGS,allow));
  field(MappedRegistry.class,"unregisteredIntrusiveHolders").set(BuiltInRegistries.ITEM,new IdentityHashMap<>());field(MappedRegistry.class,"frozen").setBoolean(BuiltInRegistries.ITEM,false);
  var gunItem=Registry.register(BuiltInRegistries.ITEM,new ResourceLocation("dimensionqa:gun"),new ModernKineticGunItem());var scopeItem=Registry.register(BuiltInRegistries.ITEM,new ResourceLocation("dimensionqa:scope"),new AttachmentItem());
  var uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);var unsafe=(sun.misc.Unsafe)uf.get(null);var player=(ServerPlayer)unsafe.allocateInstance(ServerPlayer.class);field(Player.class,"abilities").set(player,new Abilities());
  int skinCases=0,reloadCases=0;var profileRows=new ArrayList<Map<String,Object>>();var nativeDumps=new LinkedHashMap<String,Object>();
  var animJson=read(a.resolve("animations/dimension_star2.animation.json"));for(var e:animJson.getAsJsonObject("animations").entrySet())e.getValue().getAsJsonObject().remove("sound_effects");
  var animations=Animations.createAnimationFromBedrock(G.fromJson(animJson,BedrockAnimationFile.class));
  Method inverse=com.tacz.guns.client.event.FirstPersonRenderGunEvent.class.getDeclaredMethod("getPositioningNodeInverse",List.class);inverse.setAccessible(true);
  double tanY=Math.tan(Math.toRadians(calibration.fitted_vertical_fov_degrees/2)),tanX=tanY*1920/1080;
  for(String gun:DimensionScopes.GUNS) {
   var parsed=TimelessAPI.getCommonGunIndex(id(gun)).orElseThrow().getGunData();check(parsed.getExclusiveAttachments().size()==3&&parsed.getAllowAttachments().contains(AttachmentType.SCOPE),"Exclusive scopes not parsed");check(parsed.getAmmoAmount()==12&&parsed.getRoundsPerMinute()==200&&parsed.getMeleeData().getDefaultMeleeData().getDamage()==2,"Preserved mechanical values");
   var stack=new ItemStack(gunItem);gunItem.setGunId(stack,id(gun));gunItem.setCurrentAmmoCount(stack,7);gunItem.setBulletInBarrel(stack,true);stack.getOrCreateTag().putString("CustomNameEvidence","preserved");var clean=stack.getTag().copy();
   for(String skin:new String[]{"frozen","neon","royal","frozen"}) {
    var scope=new ItemStack(scopeItem);scopeItem.setAttachmentId(scope,id(skin+"_scope"));check(scopeItem.getType(scope)==AttachmentType.SCOPE&&gunItem.allowAttachment(stack,scope),"Native exclusive install not allowed");
    gunItem.installAttachment(stack,scope);DimensionScopes.sync(stack);check(gunItem.getGunDisplayId(stack).equals(id(gun+"_"+skin+"_display")),"Native install/display route");
    check(gunItem.getCurrentAmmoCount(stack)==7&&gunItem.hasBulletInBarrel(stack)&&stack.getTag().getString("CustomNameEvidence").equals("preserved"),"Install changed unrelated NBT");
    check(AttachmentDataUtils.getAmmoCountWithAttachment(stack,parsed)==12&&DimensionMeleeInput.matches(stack),"Scope changed capacity or melee routing");
    var serialized=stack.save(new net.minecraft.nbt.CompoundTag());var restored=ItemStack.of(serialized);DimensionScopes.sync(restored);check(restored.getTag().equals(stack.getTag()),"Save/reload changed selected skin");skinCases++;
   }
   gunItem.unloadAttachment(stack,AttachmentType.SCOPE);DimensionScopes.sync(stack);check(gunItem.getAttachment(stack,AttachmentType.SCOPE).isEmpty(),"Native unload did not clear scope");var afterUnload=stack.getTag().copy();afterUnload.remove(GunItemDataAccessor.GUN_ATTACHMENT_BASE+AttachmentType.SCOPE);check(afterUnload.equals(clean),"Unload changed unrelated NBT or did not restore base display");skinCases++;
   for(String skin:new String[]{"","frozen","neon","royal"}) {
    String key=DimensionScopes.profile(id(gun),skin);var display=read(a.resolve("display/guns/"+key+"_display.json"));check(display.get("animation").getAsString().equals("ssjj_dimension:dimension_star2"),"Accepted animation route changed");
    var model=new BedrockGunModel(G.fromJson(Files.readString(a.resolve("geo_models/gun/"+key+"_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);var mesh=(DimensionMeshRenderer.Geometry)meshes.get(key);DimensionMeshRenderer.attach(model,mesh);DimensionParticleEffects.bind(model,key);
    check(field(DimensionParticleEffects.class,"bindings").get(null)instanceof Map<?,?>bindings&&bindings.get(model)==particleProfiles.get(key),"Particle profile binding");
    for(var type:AttachmentType.values())check(model.getRefitAttachmentViewPath(type)==model.getRefitAttachmentViewPath(AttachmentType.NONE),"Refit slot crops gun");
    var controller=new AnimationController(animations,model);controller.runAnimation(2,"static_idle",ObjectAnimation.PlayType.LOOP,0);controller.setBlending(2,false);controller.setUpdatingTrackArray(List.of(2));DimensionNativeCheck.pause(controller,2,0);model.cleanAnimationTransform();controller.update();
    var views=new LinkedHashMap<String,Object>();int refitOutside=0;
    for(String view:new String[]{"hip","refit","fixed"}) {
     Matrix4f camera=DimensionViewCheck.chain(inverse,model,0,view.equals("refit")?1:0);
     if(view.equals("fixed")){var method=DimensionViewCheck.fixedPosition();var p=new com.mojang.blaze3d.vertex.PoseStack();p.translate(0,1.5,0);p.scale(-1,-1,1);method.invoke(null,model.getFixedOriginPath(),p,new Vector3f(1));camera=new Matrix4f(p.last().pose());camera.m32(camera.m32()-3);}
     var positions=new LinkedHashMap<String,Object>();int outside=0;
     for(var part:mesh.parts)if(!DimensionMeshRenderer.effect(part)) {
      Matrix4f matrix=new Matrix4f(camera).mul(DimensionNativeCheck.node(model,part.bone));List<float[]> ps=new ArrayList<>();
      for(float[] point:part.positions){Vector3f v=matrix.transformPosition(new Vector3f(point));check(Float.isFinite(v.x)&&Float.isFinite(v.y)&&Float.isFinite(v.z),"Nonfinite native view");if(v.z>=-.02||Math.abs(v.x)>-v.z*tanX||Math.abs(v.y)>-v.z*tanY)outside++;ps.add(new float[]{v.x,v.y,v.z});}positions.put(part.bone,ps);
     }
     if(!view.equals("hip"))check(outside==0,key+" complete display outside "+view);if(view.equals("refit"))refitOutside=outside;views.put(view,positions);
    }
    nativeDumps.put(key,views);var particle=(DimensionParticles.Data)particleProfiles.get(key);for(int sample=0;sample<20;sample++)DimensionParticles.sample(particle,sample*.173f,new Vector3f(1,0,0),new Vector3f(0,1,0));
    for(boolean creative:new boolean[]{false,true})for(var side:LogicalSide.values())for(boolean chamber:new boolean[]{false,true})for(int ammo:new int[]{0,7,11,12,13})for(boolean canceled:new boolean[]{false,true}) {
     player.getAbilities().instabuild=creative;var test=stack.copy();gunItem.setCurrentAmmoCount(test,ammo);gunItem.setBulletInBarrel(test,chamber);if(!skin.isEmpty()){var scope=new ItemStack(scopeItem);scopeItem.setAttachmentId(scope,id(skin+"_scope"));gunItem.installAttachment(test,scope);}DimensionScopes.sync(test);var before=test.getTag().copy();var event=new GunReloadEvent(player,test,side);event.setCanceled(canceled);DimensionReloadProtection.reload(event);check(event.isCanceled()==(canceled||ammo>=12),"Full reload protection");check(before.equals(test.getTag()),"Reload guard mutated NBT");reloadCases++;
    }
    profileRows.add(Map.of("profile",key,"native_model_attached",true,"refit_body_outside",refitOutside,"particle_emitters",particle.emitters.length));
   }
  }
  for(String skin:DimensionScopes.SKINS){var display=G.fromJson(Files.readString(a.resolve("display/attachments/"+skin+"_scope_display.json")),AttachmentDisplay.class);check(display.getZoom()[0]==1,"Unexpected ADS zoom");new BedrockAttachmentModel(G.fromJson(Files.readString(a.resolve("geo_models/attachment/"+skin+"_scope_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);}
  var foreign=new ItemStack(gunItem);gunItem.setGunId(foreign,new ResourceLocation("other:dimension_star"));foreign.getOrCreateTag().putString("GunDisplayId","other:custom");var before=foreign.getTag().copy();DimensionScopes.sync(foreign);check(before.equals(foreign.getTag())&&!DimensionMeleeInput.matches(foreign),"Foreign gun mutated");
  var report=new LinkedHashMap<String,Object>();report.put("passed",true);report.put("profiles",profileRows);report.put("registered_reload_callbacks",listeners.size());report.put("registered_resource_reads",reads[0]);report.put("wrapper_keys",wrappers);report.put("native_scope_install_switch_save_unload_cases",skinCases);report.put("native_reload_cases",reloadCases);report.put("full_client_test",false);report.put("boundary","Actual installed Forge naming/event registration and registered callbacks; standalone parent-event cache initialized explicitly. Real TaCZ cache/data/model/animation/view/attachment NBT/save and reload guard APIs execute. Resource access is backed by candidate files. ServerPlayer host carries native Abilities without a world. No GUI, physical input, GL, server networking or full-client start.");Files.writeString(w.resolve("evidence/family_native.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));Files.writeString(w.resolve("evidence/family_native_vertices.json"),G.toJson(nativeDumps));System.out.println("PASS native family profiles=12 scope cases="+skinCases+" reload cases="+reloadCases);System.exit(0);
 }
}
