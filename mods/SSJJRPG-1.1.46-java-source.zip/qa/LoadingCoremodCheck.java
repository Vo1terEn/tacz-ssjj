import com.google.gson.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import javax.script.*;
import net.minecraftforge.fml.*;
import net.minecraftforge.forgespi.language.IModInfo;
import net.minecraftforge.forgespi.language.IConfigurable;
import org.apache.maven.artifact.versioning.DefaultArtifactVersion;
import org.openjdk.nashorn.api.scripting.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Execute shipped Nashorn scripts against actual upstream class bytes and the real pack admission method. */
public final class LoadingCoremodCheck {
 static class HostMod extends ModContainer {
  HostMod(IModInfo info){super(info);}
  public boolean matches(Object o){return false;}
  public Object getMod(){return null;}
 }
 static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
 static byte[] entry(JarFile jar,String path)throws IOException{
  var e=jar.getJarEntry(path);if(e==null)return null;
  try(var stream=jar.getInputStream(e)){return stream.readAllBytes();}
 }
 static ClassNode read(byte[] bytes){var node=new ClassNode();new ClassReader(bytes).accept(node,0);return node;}
 static byte[] write(ClassNode node){var writer=new ClassWriter(0);node.accept(writer);return writer.toByteArray();}
 static MethodNode method(ClassNode node,String name,String descriptor){
  return node.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals(descriptor)).findFirst().orElseThrow();
 }
 static int calls(MethodNode method,String owner,String name,String descriptor){
  int count=0;for(var instruction:method.instructions)if(instruction instanceof MethodInsnNode call
    &&call.owner.equals(owner)&&call.name.equals(name)&&call.desc.equals(descriptor))count++;return count;
 }
 static void rejected(ScriptObjectMirror transformer,ClassNode broken,String expected){
  try{transformer.call(null,broken);}catch(RuntimeException failure){
   require(failure.getMessage()!=null&&failure.getMessage().contains(expected),"Wrong negative-control failure: "+failure);return;
  }
  throw new AssertionError("Broken upstream router was accepted");
 }
 static Map<String,Object> skillContracts(String key,byte[] original,ClassNode transformed,ScriptObjectMirror transformer){
  var checks=new LinkedHashMap<String,Object>();
  if(key.equals("ssjj_weapon_asset_warmup")){
   var reload=method(transformed,"reload","()V");
   require(calls(reload,"cn/ssjjcompat/WeaponAssetWarmup","prepare","()V")==1,"Expected one loading-stage preparation hook");
   int returns=0;
   for(var instruction:reload.instructions)if(instruction.getOpcode()==Opcodes.RETURN){
    returns++;
    require(instruction.getPrevious() instanceof MethodInsnNode call&&call.owner.equals("cn/ssjjcompat/WeaponAssetWarmup")&&call.name.equals("prepare"),"Preparation not at normal reload completion");
   }
   require(returns==1,"Unexpected reload return count");
   var normalized=read(original);
   method(normalized,"reload","()V").instructions.clear();
   var unrelated=read(write(transformed));method(unrelated,"reload","()V").instructions.clear();
   require(Arrays.equals(write(normalized),write(unrelated)),"Preparation changed unrelated index methods or metadata");
   for(String change:List.of("missing_method","extra_return","nonstatic")){
    var broken=read(original);var target=method(broken,"reload","()V");
    if(change.equals("missing_method"))target.name="qaMissingReload";
    else if(change.equals("extra_return"))target.instructions.add(new InsnNode(Opcodes.RETURN));
    else target.access&=~Opcodes.ACC_STATIC;
    rejected(transformer,broken,change.equals("nonstatic")?"reload is no longer static":"unsupported client resource reload layout");
   }
   checks.put("normal_return_hook_count",1);checks.put("unrelated_methods_unchanged",true);checks.put("reload_negative_controls",3);
  }else if(key.equals("judgment_input_router")){
   String descriptor="(Lcom/mojang/blaze3d/platform/InputConstants$Key;)V";
   var routed=method(transformed,"onPress",descriptor);
   require(calls(routed,"cn/ssjjcompat/SkillInputCompat","run","(Ljava/lang/Runnable;Lcom/mojang/blaze3d/platform/InputConstants$Key;Lnet/minecraft/client/KeyMapping;)V")==1,"Expected exactly one skill-input bridge");
   require(calls(routed,"java/lang/Runnable","run","()V")==0,"Original direct Runnable invocation survived");
   for(String change:List.of("missing_method","missing_call","broken_binding")){
    var broken=read(original);var press=method(broken,"onPress",descriptor);
    if(change.equals("missing_method"))press.name="qaMissingOnPress";
    else for(var instruction:press.instructions)if(instruction instanceof MethodInsnNode call){
     if(change.equals("missing_call")&&call.owner.equals("java/lang/Runnable")&&call.name.equals("run"))call.name="qaMissingRun";
     if(change.equals("broken_binding")&&call.name.equals("action")&&call.desc.equals("()Ljava/lang/Runnable;"))call.name="qaBrokenAction";
    }
    rejected(transformer,broken,change.equals("broken_binding")?"unsupported router binding layout":"unsupported centralized input router");
   }
   checks.put("unique_bridge_and_no_direct_runnable",true);checks.put("router_negative_controls",3);
  }else if(key.equals("judgment_zoom_skill_key")||key.equals("judgment_melee_skill_key")){
   boolean zoom=key.equals("judgment_zoom_skill_key");String descriptor="(Lnet/minecraftforge/client/event/InputEvent$Key;)V";
   var baseline=read(original);String legacy=zoom?"onZoomKeyPress":"onMeleeKeyPress";
   boolean old=baseline.methods.stream().anyMatch(m->m.name.equals(legacy)&&m.desc.equals(descriptor));
   if(old){
    require(calls(method(transformed,legacy,descriptor),"cn/judgfire/JudgmentSkillKey","reserved","(Lnet/minecraftforge/client/event/InputEvent$Key;)Z")==1,"Missing or duplicated legacy reservation guard");
    checks.put("legacy_reserved_guard_count",1);
   }else{
    method(baseline,zoom?"onZoomPress":"onMeleePress","()Z");
    require(Arrays.equals(write(baseline),write(transformed)),"Modern no-argument skill-key class behavior changed");
    checks.put("modern_class_instructions_unchanged",true);
   }
  }
  return checks;
 }
 static List<Map<String,Object>> transforms(Path mod,Path dependency)throws Exception{
  var reports=new ArrayList<Map<String,Object>>();
  try(var jar=new JarFile(mod.toFile());var targetJar=new JarFile(dependency.toFile())){
   var metadata=JsonParser.parseString(new String(entry(jar,"META-INF/coremods.json"),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
   for(var declared:metadata.entrySet()){
    String script=declared.getValue().getAsString();
    var engine=new NashornScriptEngineFactory().getScriptEngine("--language=es6");
    engine.eval(new String(entry(jar,script),java.nio.charset.StandardCharsets.UTF_8));
    var definitions=(ScriptObjectMirror)((Invocable)engine).invokeFunction("initializeCoreMod");
    for(String key:definitions.keySet()){
     var definition=(ScriptObjectMirror)definitions.get(key);var target=(ScriptObjectMirror)definition.get("target");
     String name=String.valueOf(target.get("name"));if(!name.startsWith("com.tacz."))continue;
     require("CLASS".equals(target.get("type")),"Unexpected target kind "+key);
     byte[] bytes=entry(targetJar,name.replace('.','/')+".class");
     if(bytes==null){
      require(name.equals("com.tacz.guns.client.input.GunInputHandler"),"Missing existing upstream target "+name);
      reports.add(Map.of("target",name,"transformer",key,"absent_new_version_only_target",true));continue;
     }
     var node=read(bytes);var transformer=(ScriptObjectMirror)definition.get("transformer");
     var transformed=(ClassNode)transformer.call(null,node);
     require(transformed!=null,"Transformer returned null "+key);
     var contracts=skillContracts(key,bytes,transformed,transformer);
     int methods=0;
     for(var method:transformed.methods){
      if((method.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))!=0)continue;
      new Analyzer<>(new BasicVerifier()).analyze(transformed.name,method);methods++;
     }
     var output=write(transformed);new ClassReader(output);
     reports.add(Map.of("script",script,"transformer",key,"target",name,"methods_verified",methods,
        "changed",!Arrays.equals(write(read(bytes)),output),"skill_contract_checks",contracts));
    }
   }
  }
  require(reports.size()>=12,"Incomplete coremod target coverage");return reports;
 }
 static void packGate(Path candidate,Path negative,String version)throws Exception{
  // ModContainer reads the ordinary display-test metadata during construction.
  // Supply that host metadata without replacing the real loader or version check.
  var config=new IConfigurable(){
   @SuppressWarnings("unchecked") public <T> Optional<T> getConfigElement(String... path){
    require(Arrays.equals(path,new String[]{"displayTest"}),"Unexpected host config lookup "+Arrays.toString(path));
    return Optional.of((T)"MATCH_VERSION");
   }
   public List<? extends IConfigurable> getConfigList(String... path){throw new AssertionError("Unexpected host config list lookup");}
  };
  var info=(IModInfo)Proxy.newProxyInstance(IModInfo.class.getClassLoader(),new Class[]{IModInfo.class},(p,m,a)->switch(m.getName()){
   case "getModId","getNamespace"->"tacz";case "getVersion"->new DefaultArtifactVersion(version);
   case "getConfig"->config;
   case "toString"->"Actual version metadata test host";default->throw new AssertionError("Unexpected metadata host method "+m.getName());
  });
  var mods=ModList.of(List.of(),List.of());var indexed=ModList.class.getDeclaredField("indexedMods");indexed.setAccessible(true);indexed.set(mods,Map.of("tacz",new HostMod(info)));
  var loader=Class.forName("com.tacz.guns.resource.GunPackLoader");
  var parse=loader.getDeclaredMethod("fromZipPath",Path.class);parse.setAccessible(true);
  require(parse.invoke(null,candidate)!=null,"Actual GunPackLoader rejected final gunpack "+version);
  if(version.equals("1.2.0"))require(parse.invoke(null,negative)==null,"Negative control failed: old bound should reject 1.2.0");
 }
 public static void main(String[] args)throws Exception{
  if(args.length!=6)throw new IllegalArgumentException("mod.jar tacz.jar pack.zip negative.zip version report.json");
  var rows=transforms(Path.of(args[0]),Path.of(args[1]));packGate(Path.of(args[2]),Path.of(args[3]),args[4]);
  var report=Map.of("passed",true,"version",args[4],"actual_gunpack_loader_admission",true,
     "old_pack_rejection_negative_control",args[4].equals("1.2.0"),"nashorn_targets",rows,
     "boundary","Each shipped Nashorn transformer executes independently on original upstream class bytes, with ASM BasicVerifier for every concrete method; this does not test composition of multiple transformers. Skill-key guard/unchanged-modern contracts and router mutation negative controls execute. Actual GunPackLoader.fromZipPath uses real version metadata in a minimal Forge ModList host. No GL, full client, server or gameplay execution.");
  Files.writeString(Path.of(args[5]),new GsonBuilder().setPrettyPrinting().create().toJson(report));
  System.out.println("PASS actual pack admission and "+rows.size()+" Nashorn targets for TaCZ "+args[4]);
 }
}
