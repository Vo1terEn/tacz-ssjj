import cn.ssjjdimension.client.DimensionParticles;
import com.google.gson.*;
import com.tacz.guns.api.client.animation.*;
import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile;
import com.tacz.guns.client.resource.pojo.model.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import org.joml.*;
import java.lang.Math;

/** Production particle sampler through native animated bone and camera basis. */
public class DimensionGlintCheck {
 static final Gson G=DimensionNativeCheck.GSON;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static DimensionParticles.Data one(DimensionParticles.Data d,DimensionParticles.Emitter e){var x=new DimensionParticles.Data();x.schema=d.schema;x.gun=d.gun;x.bone=d.bone;x.emitters=new DimensionParticles.Emitter[]{e};return x;}
 static double angle(Matrix4f m,DimensionParticles.Mesh mesh,Vector3f axis){var p=mesh.positions;var v=m.transformDirection(new Vector3f(p[3][0]-p[0][0],p[3][1]-p[0][1],p[3][2]-p[0][2]));var expected=m.transformDirection(new Vector3f(axis));double dot=(v.x*expected.x+v.y*expected.y)/(Math.hypot(v.x,v.y)*Math.hypot(expected.x,expected.y));return Math.toDegrees(Math.acos(Math.min(1,Math.abs(dot))));}
 public static void main(String[]args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
  Path w=Path.of(args[0]),a=w.resolve("pack/assets/ssjj_dimension");var raw=DimensionNativeCheck.read(a.resolve("animations/dimension_star2.animation.json"));for(var e:raw.getAsJsonObject("animations").entrySet())e.getValue().getAsJsonObject().remove("sound_effects");var anims=Animations.createAnimationFromBedrock(G.fromJson(raw,BedrockAnimationFile.class));
  Method inv=com.tacz.guns.client.event.FirstPersonRenderGunEvent.class.getDeclaredMethod("getPositioningNodeInverse",List.class);inv.setAccessible(true);
  var rows=new ArrayList<Map<String,Object>>();var snapshots=new ArrayList<Map<String,Object>>();int axes=0,missing=0;double maxError=0,minimumNegative=180;
  try(var z=new java.util.zip.ZipFile(w.resolve("baseline/tacz/[SSJJRPG]生死狙击冒险枪包.zip").toFile())){
   for(String gun:cn.ssjjdimension.DimensionScopes.GUNS)for(String skin:new String[]{"","_frozen","_neon","_royal"}){
    String key=gun+skin,file=key.equals("dimension_star2")?"effects/particles.json":"effects/particles_"+key+".json";
    var data=G.fromJson(Files.readString(a.resolve(file)),DimensionParticles.Data.class);DimensionParticles.validate(data);var old=G.fromJson(new String(z.getInputStream(z.getEntry("assets/ssjj_dimension/"+file)).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8),DimensionParticles.Data.class);
    var model=new BedrockGunModel(G.fromJson(Files.readString(a.resolve("geo_models/gun/"+key+"_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);var c=new AnimationController(anims,model);c.runAnimation(2,"static_idle",ObjectAnimation.PlayType.LOOP,0);c.setBlending(2,false);c.setUpdatingTrackArray(List.of(2));DimensionNativeCheck.pause(c,2,0);c.update();
    for(int i=0;i<data.emitters.length;i++){
     var e=data.emitters[i];if(e.billboard_axis==null)continue;axes++;check(e.name.equals(old.emitters[i].name),"Emitter order changed");boolean repaired=old.emitters[i].billboard_axis==null;if(repaired)missing++;
     var axis=new Vector3f(e.billboard_axis[0],e.billboard_axis[1],e.billboard_axis[2]);var p=e.particles[0];float clock=p.birth+p.life*.5f;double maximum=0,negative=0;
     for(String view:new String[]{"hip","refit"}){
      Matrix4f m=DimensionViewCheck.chain(inv,model,0,view.equals("refit")?1:0).mul(DimensionNativeCheck.node(model,data.bone));var inverse=new Matrix3f(m).invert();var right=inverse.transform(new Vector3f(1,0,0)).normalize();var up=inverse.transform(new Vector3f(0,1,0)).normalize();
      var batches=DimensionParticles.sample(one(data,e),clock,right,up);check(!batches.isEmpty(),"No glint at midpoint");var mesh=batches.get(0).mesh();double error=angle(m,mesh,axis);check(error<.05,"Source glint long axis changed: "+key+" / "+e.name+" "+error);maximum=Math.max(maximum,error);maxError=Math.max(maxError,error);
      var before=DimensionParticles.sample(one(old,old.emitters[i]),clock,right,up);double wrong=angle(m,before.get(0).mesh(),axis);negative=Math.max(negative,wrong);
      if(repaired&&view.equals("hip")){
       var points=new ArrayList<float[]>();var previous=new ArrayList<float[]>();for(var x:mesh.positions){var v=m.transformPosition(new Vector3f(x));points.add(new float[]{v.x,v.y,v.z});}for(var x:before.get(0).mesh().positions){var v=m.transformPosition(new Vector3f(x));previous.add(new float[]{v.x,v.y,v.z});}
       snapshots.add(Map.of("profile",key,"emitter",e.name,"corrected_camera_vertices",points,"previous_camera_vertices",previous));
      }
     }
     if(repaired){check(negative>10,"Negative direction control did not fail");minimumNegative=Math.min(minimumNegative,negative);}
     rows.add(Map.of("profile",key,"emitter",e.name,"source_axis",e.billboard_axis,"repaired",repaired,"maximum_axis_error_degrees",maximum,"previous_error_degrees",negative));
    }
   }
  }
  check(axes==24&&missing==6,"Expected 24 source elongated glints, six name-filter misses");var report=new LinkedHashMap<String,Object>();report.put("passed",true);report.put("source_glints",axes);report.put("repaired_emitters",missing);report.put("views_per_emitter",2);report.put("maximum_native_axis_error_degrees",maxError);report.put("minimum_previous_wrong_axis_degrees",minimumNegative);report.put("emitters",rows);report.put("live_client_test",false);report.put("boundary","Actual native model animation, positioning-node inverse camera chain and production particle sampler. Direction compared to independent source axis in camera coordinates; no GL, lighting or full-client visual pass.");Files.writeString(w.resolve("evidence/glint_native.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));Files.writeString(w.resolve("evidence/glint_camera_vertices.json"),G.toJson(snapshots));System.out.println("PASS glints="+axes+" repaired="+missing+" max angle="+maxError+" old wrong minimum="+minimumNegative);System.exit(0);
 }
}
