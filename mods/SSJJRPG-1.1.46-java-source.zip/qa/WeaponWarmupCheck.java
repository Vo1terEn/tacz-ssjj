import com.google.gson.*;
import com.tacz.guns.client.resource.*;
import com.tacz.guns.client.resource.pojo.display.gun.GunDisplay;
import com.mojang.blaze3d.platform.NativeImage;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.*;
import net.minecraft.util.profiling.InactiveProfiler;

/** Real TaCZ reload/data/model/runtime preparation; texture consumer decodes PNGs without GL. */
public final class WeaponWarmupCheck {
 static int reads,assertions;
 static final Map<ResourceLocation,Path> files=new LinkedHashMap<>();
 static void check(boolean value,String message){assertions++;if(!value)throw new AssertionError(message);}
 static Field field(Class<?> c,String name)throws Exception{var f=c.getDeclaredField(name);f.setAccessible(true);return f;}
 static Resource resource(ResourceLocation id,PackResources pack){return new Resource(pack,()->{reads++;return Files.newInputStream(files.get(id));});}
 static ResourceManager resources(Path root)throws Exception{
  try(var paths=Files.walk(root.resolve("assets"))){for(Path p:paths.filter(Files::isRegularFile).sorted().toList()){
   var relative=root.resolve("assets").relativize(p);files.put(new ResourceLocation(relative.getName(0).toString(),relative.subpath(1,relative.getNameCount()).toString().replace('\\','/')),p);
  }}
  var pack=(PackResources)Proxy.newProxyInstance(WeaponWarmupCheck.class.getClassLoader(),new Class[]{PackResources.class},(p,m,a)->switch(m.getName()){
   case "m_5542_"->"actual paired gunpack QA host";case "m_246538_"->false;case "close"->null;default->throw new AssertionError("Unexpected pack method "+m);
  });
  return (ResourceManager)Proxy.newProxyInstance(WeaponWarmupCheck.class.getClassLoader(),new Class[]{ResourceManager.class},(p,m,a)->{
   if(m.isDefault())return InvocationHandler.invokeDefault(p,m,a);
   if(m.getName().equals("m_213713_")){var id=(ResourceLocation)a[0];return files.containsKey(id)?Optional.of(resource(id,pack)):Optional.empty();}
   if(m.getName().equals("m_214159_")){
    var found=new LinkedHashMap<ResourceLocation,Resource>();String directory=(String)a[0];
    @SuppressWarnings("unchecked") var predicate=(Predicate<ResourceLocation>)a[1];
    for(var id:files.keySet())if(id.m_135815_().startsWith(directory+"/")&&predicate.test(id))found.put(id,resource(id,pack));return found;
   }
   throw new AssertionError("Unexpected resource method "+m);
  });
 }
 static void reload(ResourceManager resources)throws Exception{
  var manager=ClientAssetsManager.INSTANCE;manager.reloadAndRegister(ignored->{});
  var barrier=new PreparableReloadListener.PreparationBarrier(){public <T> CompletableFuture<T> m_6769_(T value){return CompletableFuture.completedFuture(value);}};
  // Use registered real upstream loaders; do not invoke ClientIndexManager's MC/player-dependent callback.
  for(String name:List.of("gunDisplay","bedrockModel","bedrockAnimation","gltfAnimation","scriptManager","adsPresets")){
   Field f;try{f=field(ClientAssetsManager.class,name);}catch(NoSuchFieldException absent){check(name.equals("adsPresets"),"Missing required manager "+name);continue;}
   var listener=(PreparableReloadListener)f.get(manager);
   listener.m_5540_(barrier,resources,InactiveProfiler.f_18554_,InactiveProfiler.f_18554_,Runnable::run,Runnable::run).join();
  }
  // TextureStitch normally seeds these defaults; prepare the exact official prototypes without MC/GL.
  for(String kind:List.of("Pistol","Rifle")){
   var location=new ResourceLocation("tacz", "animations/"+kind.toLowerCase()+"_default.animation.json");
   try(var reader=Files.newBufferedReader(files.get(location))){
    var animation=ClientAssetsManager.GSON.fromJson(reader,com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile.class);
    field(InternalAssetLoader.class,"default"+kind+"Animations").set(null,com.tacz.guns.api.client.animation.Animations.createAnimationFromBedrock(animation));
   }
  }
 }
 static Map<ResourceLocation,GunDisplayInstance> displays()throws Exception{
  var output=new LinkedHashMap<ResourceLocation,GunDisplayInstance>();
  for(var entry:files.entrySet()){
   var id=entry.getKey();String path=id.m_135815_();
   if(!(id.m_135827_().equals("judgfire")||id.m_135827_().equals("ssjj_dark"))||!path.startsWith("display/guns/")||!path.endsWith(".json"))continue;
   var displayId=new ResourceLocation(id.m_135827_(),path.substring("display/guns/".length(),path.length()-5));
   var pojo=ClientAssetsManager.INSTANCE.getGunDisplay(displayId);
   check(pojo!=null,"Actual display loader rejected "+displayId);
   output.put(displayId,GunDisplayInstance.create(displayId,pojo));
  }
  return output;
 }
 static Object state(Object machine)throws Exception{
  // Snapshot all reference fields: preparation/getters must not initialize an active context/state.
  var result=new LinkedHashMap<String,Object>();
  for(Class<?> type=machine.getClass();type!=null;type=type.getSuperclass())for(var f:type.getDeclaredFields())if(!Modifier.isStatic(f.getModifiers())){
   f.setAccessible(true);Object v=f.get(machine);if(v instanceof Collection<?> list)v=new ArrayList<>(list);if(v instanceof Map<?,?> map)v=new LinkedHashMap<>(map);result.put(type.getName()+"."+f.getName(),v);
  }
  return result;
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
  net.minecraft.SharedConstants.m_142977_();
  var mods=net.minecraftforge.fml.ModList.of(List.of(),List.of());var loaded=net.minecraftforge.fml.ModList.class.getDeclaredMethod("setLoadedMods",List.class);loaded.setAccessible(true);loaded.invoke(mods,List.of());
  var config=new net.minecraftforge.common.ForgeConfigSpec.Builder();com.tacz.guns.config.client.ResourceConfig.init(config);config.build().setConfig(com.electronwill.nightconfig.core.CommentedConfig.inMemory());
  var resourceManager=resources(Path.of(args[0]));reload(resourceManager);
  var prepare=Class.forName("cn.ssjjcompat.WeaponAssetWarmup").getDeclaredMethod("prepare",Map.class,Consumer.class);prepare.setAccessible(true);
  var first=displays();check(first.size()==18,"Expected all 18 selected display files");
  var foreignPojo=ClientAssetsManager.GSON.fromJson("{\"model\":\"foreign:missing\",\"texture\":\"foreign:missing\"}",GunDisplay.class);
  var foreign=GunDisplayInstance.create(new ResourceLocation("foreign:untouched"),foreignPojo);
  first.put(new ResourceLocation("foreign:untouched"),foreign);
  first.put(new ResourceLocation("judgfire:alias"),first.values().iterator().next());
  var textures=new ArrayList<ResourceLocation>();long[] decodeNanos={0},pixels={0};
  Consumer<ResourceLocation> decoder=id->{
   try{long start=System.nanoTime();check(files.containsKey(id),"Missing actual texture "+id);
    try(var image=NativeImage.m_85058_(Files.newInputStream(files.get(id)))){pixels[0]+=(long)image.m_84982_()*image.m_85084_();}
    decodeNanos[0]+=System.nanoTime()-start;textures.add(id);
   }catch(Exception failure){throw new RuntimeException(failure);}
  };
  int before=reads;long started=System.nanoTime();int prepared=(int)prepare.invoke(null,first,decoder);long coldNanos=System.nanoTime()-started;
  check(prepared==18,"Preparation lost a display or counted alias/foreign object");
  check(new HashSet<>(textures).size()==textures.size(),"Duplicate texture loads");
  check(textures.size()==12,"Expected 12 actual shared model/LOD textures, found "+textures.size());
  long firstDecodeNanos=decodeNanos[0],firstPixels=pixels[0];
  check(reads>before,"Native loader cold path did not read actual resources");
  check(field(GunDisplayInstance.class,"gunModel").get(foreign)==null,"Foreign namespace model loaded");
  check(field(GunDisplayInstance.class,"animationStateMachine").get(foreign)==null,"Foreign namespace runtime loaded");
  var identities=new IdentityHashMap<GunDisplayInstance,Object[]>();
  for(var entry:first.entrySet())if(entry.getKey().m_135827_().equals("judgfire")||entry.getKey().m_135827_().equals("ssjj_dark")){
   var d=entry.getValue();var machine=d.getAnimationStateMachine();check(d.getGunModel()!=null&&machine!=null,"Native loading failed: "+entry.getKey());
   check(!machine.isInitialized()&&machine.getContext()==null,"Preparation started an animation state machine");
   identities.put(d,new Object[]{d.getGunModel(),machine,state(machine),d.getLodModel()});
  }
  int coldReads=reads-before;before=reads;started=System.nanoTime();
  for(var entry:identities.entrySet()){
   var d=entry.getKey();var saved=entry.getValue();check(d.getGunModel()==saved[0]&&d.getAnimationStateMachine()==saved[1]&&d.getLodModel()==saved[3],"Prepared object identity changed");
   check(state(d.getAnimationStateMachine()).equals(saved[2]),"Animation initial state changed");
  }
  long hotNanos=System.nanoTime()-started;check(reads==before,"First-use getter repeated resource reads");
  reload(resourceManager);var second=displays();textures.clear();before=reads;
  check((int)prepare.invoke(null,second,decoder)==18,"Reload instances not prepared");
  check(reads>before,"Actual resource-manager reload did not rebuild lazy assets");
  for(var entry:second.entrySet())check(entry.getValue().getGunModel()!=first.get(entry.getKey()).getGunModel(),"Reload reused old model instance");
  // A real malformed upstream display should keep its null-model failure behavior and not request textures.
  var brokenPojo=ClientAssetsManager.GSON.fromJson("{\"model\":\"judgfire:missing\",\"texture\":\"judgfire:missing\"}",GunDisplay.class);
  var broken=GunDisplayInstance.create(new ResourceLocation("judgfire:missing"),brokenPojo);
  check((int)prepare.invoke(null,Map.of(new ResourceLocation("judgfire:missing"),broken),(Consumer<ResourceLocation>)id->{throw new AssertionError("Failed model requested texture");})==0,"Null-model failure changed");
  var report=new LinkedHashMap<String,Object>();report.put("passed",true);report.put("version",args[1]);report.put("assertions",assertions);report.put("target_displays",prepared);report.put("unique_model_lod_textures",12);report.put("native_cold_resource_reads",coldReads);report.put("hot_getter_resource_reads",0);report.put("cold_prepare_cpu_ms",coldNanos/1e6);report.put("cold_model_runtime_cpu_ms",(coldNanos-firstDecodeNanos)/1e6);report.put("hot_getters_cpu_ms",hotNanos/1e6);report.put("first_native_png_decode_cpu_ms",firstDecodeNanos/1e6);report.put("native_png_decode_cpu_ms_two_rounds",decodeNanos[0]/1e6);report.put("first_texture_rgba_bytes",firstPixels*4);report.put("boundary","Actual upstream registered display/model/animation/script loaders and native GunDisplayInstance getters execute. Official default animation prototypes seed the normally TextureStitch-driven cache without starting MC/GL. Genuine ForgeConfigSpec is in memory, with native lazy default enabled. Consumer uses real NativeImage PNG decoding instead of TextureManager GL upload. No fake TaCZ core classes; ResourceManager is a file-backed host. No full client/frame-time/GPU/physical input/audio validation. Timing is CPU observation, no speed threshold or FPS claim.");
  Files.writeString(Path.of(args[2]),new GsonBuilder().setPrettyPrinting().create().toJson(report));System.out.println("PASS weapon preparation "+args[1]+" displays="+prepared+" textures=12 assertions="+assertions);System.exit(0);
 }
}
