import cn.ssjjdimension.DimensionMeleeInput;
import com.google.gson.*;
import com.electronwill.nightconfig.core.CommentedConfig;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.entity.*;
import com.tacz.guns.client.gameplay.LocalPlayerDataHolder;
import com.tacz.guns.client.input.*;
import com.tacz.guns.config.client.KeyConfig;
import com.tacz.guns.item.ModernKineticGunItem;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.client.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.*;
import org.objectweb.asm.*;

/** Direct genuine subscribers with real MC/LocalPlayer types and a bounded host.
 * No window, world simulation, mixin bootstrap, network or game launcher runs.
 */
public final class DimensionInputCheck {
    static sun.misc.Unsafe U;
    static Minecraft mc;
    static Host player;
    static ClientLevel level;
    static ItemStack target,foreign;
    static Class<?> nativeInput;
    static final List<Map<String,Object>> cases=new ArrayList<>();
    static Field field(Class<?> c,String name)throws Exception{var f=c.getDeclaredField(name);f.setAccessible(true);return f;}
    static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
    static void row(String name,Object... pairs){var r=new LinkedHashMap<String,Object>();r.put("case",name);r.put("passed",true);for(int i=0;i<pairs.length;i+=2)r.put((String)pairs[i],pairs[i+1]);cases.add(r);}
    // LocalPlayer and the client-side TaCZ interface are actual dependency APIs.
    // JVM return-type overloads from the separate IGunOperator mixin are added
    // by the tiny QA-only interface bridge below (Java source cannot express
    // the two unrelated getDataHolder() return types).
    public static class Host extends LocalPlayer implements IClientPlayerGunOperator {
        ItemStack held;boolean alive,spectator,aim;int melees,aimOn,aimOff;
        long draw,meleeCooldown;boolean bolting;ReloadState reload;
        public Host(){super(null,null,null,null,null,false,false);}
        @Override public ItemStack getMainHandItem(){return held;}
        @Override public boolean isAlive(){return alive;}
        @Override public boolean isSpectator(){return spectator;}
        public ReloadState getSynReloadState(){return reload;}
        public long getSynDrawCoolDown(){return draw;}
        public boolean getSynIsBolting(){return bolting;}
        public long getSynMeleeCoolDown(){return meleeCooldown;}
        public void melee(){melees++;}
        public void aim(boolean value){aim=value;if(value)aimOn++;else aimOff++;}
        public boolean isAim(){return aim;}
        public ShootResult shoot(){throw new AssertionError("Unexpected shoot");}
        public void draw(ItemStack stack){throw new AssertionError("Unexpected draw");}
        public void bolt(){throw new AssertionError("Unexpected bolt");}
        public void reload(){throw new AssertionError("Unexpected reload");}
        public void unloadAmmo(){throw new AssertionError("Unexpected unloadAmmo");}
        public void inspect(){throw new AssertionError("Unexpected inspect");}
        public void fireSelect(){throw new AssertionError("Unexpected fireSelect");}
        public void crawl(boolean value){throw new AssertionError("Unexpected crawl");}
        public boolean isCrawl(){return false;}
        public LocalPlayerDataHolder getDataHolder(){throw new AssertionError("Unused data holder");}
        public float getClientAimingProgress(float partial){return aim?1:0;}
        public long getClientShootCoolDown(){return 0;}
        public boolean isReadyToDraw(){return true;}
        public void resetDraw(){}
        public boolean chargeShoot(boolean value){return false;}
        public float getChargeProgress(){return 0;}
        public boolean isCharging(){return false;}
    }
    public static class TestOverlay extends Overlay { public void render(GuiGraphics g,int x,int y,float p){} }
    public static class TestScreen extends Screen {public TestScreen(){super(Component.literal("QA"));}}
    static Class<?> bridge()throws Exception{
        ClassWriter w=new ClassWriter(0);
        w.visit(Opcodes.V17,Opcodes.ACC_PUBLIC|Opcodes.ACC_SUPER,"DimensionInputNativeHost",null,"DimensionInputCheck$Host",new String[]{"com/tacz/guns/api/entity/IGunOperator"});
        // Any unexercised gameplay interface call is a test failure, not a fake
        // success. Implement missing abstract methods with throwing bodies.
        for(Method m:IGunOperator.class.getMethods()){
            if(!Modifier.isAbstract(m.getModifiers()))continue;
            boolean inherited=false;
            for(Method h:Host.class.getMethods())if(h.getName().equals(m.getName())&&Arrays.equals(h.getParameterTypes(),m.getParameterTypes())&&h.getReturnType().equals(m.getReturnType()))inherited=true;
            if(inherited)continue;
            MethodVisitor v=w.visitMethod(Opcodes.ACC_PUBLIC,m.getName(),org.objectweb.asm.Type.getMethodDescriptor(m),null,null);
            v.visitCode();v.visitTypeInsn(Opcodes.NEW,"java/lang/AssertionError");v.visitInsn(Opcodes.DUP);v.visitLdcInsn("Unused QA-only IGunOperator method: "+m.getName());v.visitMethodInsn(Opcodes.INVOKESPECIAL,"java/lang/AssertionError","<init>","(Ljava/lang/Object;)V",false);v.visitInsn(Opcodes.ATHROW);
            int locals=1;for(Class<?> p:m.getParameterTypes())locals+=p==long.class||p==double.class?2:1;
            v.visitMaxs(3,locals);v.visitEnd();
        }
        w.visitEnd();return MethodHandles.lookup().defineClass(w.toByteArray());
    }
    static void reset()throws Exception{
        mc.player=player;mc.level=level;mc.screen=null;
        field(Minecraft.class,"overlay").set(mc,null);field(Minecraft.class,"pause").setBoolean(mc,false);field(Minecraft.class,"windowActive").setBoolean(mc,true);
        field(MouseHandler.class,"mouseGrabbed").setBoolean(mc.mouseHandler,true);
        player.held=target;player.alive=true;player.spectator=false;player.aim=false;player.melees=player.aimOn=player.aimOff=0;
        player.draw=player.meleeCooldown=0;player.bolting=false;player.reload=new ReloadState();
        AimKey.AIM_KEY.setDown(false);
    }
    static InputEvent.MouseButton.Pre mouse(int button,int action){var event=new InputEvent.MouseButton.Pre(button,action,0);DimensionMeleeInput.mouse(event);return event;}
    static void aimMode(boolean hold)throws Exception{KeyConfig.HOLD_TO_AIM.set(hold);}
    static void annotation(String method,Class<?> argument,EventPriority priority)throws Exception{
        var a=DimensionMeleeInput.class.getMethod(method,argument).getAnnotation(SubscribeEvent.class);
        require(a!=null&&a.priority()==priority&&!a.receiveCanceled(),"Subscriber annotation "+method);
    }
    static void nativeMousePost(int button,int action)throws Exception{
        var event=new InputEvent.MouseButton.Post(button,action,0);
        if(nativeInput!=null)nativeInput.getMethod("onMousePress",InputEvent.MouseButton.Post.class).invoke(null,event);
        else AimKey.class.getMethod("onAimPress",InputEvent.MouseButton.Post.class).invoke(null,event);
    }
    static void nativeKey(InputEvent.Key event)throws Exception{
        if(nativeInput!=null)nativeInput.getMethod("onKeyPress",InputEvent.Key.class).invoke(null,event);
        else {
            MeleeKey.class.getMethod("onMeleeKeyPress",InputEvent.Key.class).invoke(null,event);
            ZoomKey.class.getMethod("onZoomKeyPress",InputEvent.Key.class).invoke(null,event);
        }
    }
    public static void main(String[] args)throws Exception {
        Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
        var mods=net.minecraftforge.fml.ModList.of(List.of(),List.of());var loaded=net.minecraftforge.fml.ModList.class.getDeclaredMethod("setLoadedMods",List.class);loaded.setAccessible(true);loaded.invoke(mods,List.of());
        U=(sun.misc.Unsafe)field(sun.misc.Unsafe.class,"theUnsafe").get(null);
        mc=(Minecraft)U.allocateInstance(Minecraft.class);field(Minecraft.class,"instance").set(null,mc);
        field(Minecraft.class,"mouseHandler").set(mc,U.allocateInstance(MouseHandler.class));
        level=(ClientLevel)U.allocateInstance(ClientLevel.class);player=(Host)U.allocateInstance(bridge());
        field(MappedRegistry.class,"unregisteredIntrusiveHolders").set(BuiltInRegistries.ITEM,new IdentityHashMap<>());field(MappedRegistry.class,"frozen").setBoolean(BuiltInRegistries.ITEM,false);
        var item=Registry.register(BuiltInRegistries.ITEM,new ResourceLocation("dimensionqa:gun"),new ModernKineticGunItem());
        target=new ItemStack(item);item.setGunId(target,new ResourceLocation(args.length>1?args[1]:"ssjj_dimension:dimension_star2"));
        foreign=new ItemStack(item);item.setGunId(foreign,new ResourceLocation("ssjj_dimension:dimension_star3"));
        // Load existing keys first. Production input must register no new binding.
        // TaCZ 1.2 registers all press bindings in one native dispatcher.
        try{nativeInput=Class.forName("com.tacz.guns.client.input.GunInputHandler");}catch(ClassNotFoundException legacy){nativeInput=null;}
        // registerKeyMappings registers SHOOT_KEY separately from PRESS_BINDINGS.
        if(nativeInput!=null)Class.forName("com.tacz.guns.client.input.ShootKey");
        var keys=List.of(AimKey.AIM_KEY,MeleeKey.MELEE_KEY,ZoomKey.ZOOM_KEY);
        int keyCount=((Map<?,?>)field(KeyMapping.class,"ALL").get(null)).size();
        Map<String,String> savedKeys=new LinkedHashMap<>();for(var k:keys)savedKeys.put(k.getName(),k.saveString());
        var b=new ForgeConfigSpec.Builder();KeyConfig.init(b);b.build().setConfig(CommentedConfig.inMemory());
        reset();
        require(DimensionMeleeInput.matches(target),"Exact GunId");require(!DimensionMeleeInput.matches(null)&&!DimensionMeleeInput.matches(ItemStack.EMPTY)&&!DimensionMeleeInput.matches(foreign),"Foreign/empty/null GunId");
        var noTag=new ItemStack(item);require(!DimensionMeleeInput.matches(noTag),"No GunId");noTag.getOrCreateTag().putInt("GunId",1);require(!DimensionMeleeInput.matches(noTag),"Nonstring GunId");
        var nongun=new ItemStack(net.minecraft.world.item.Items.STICK);nongun.getOrCreateTag().putString("GunId","ssjj_dimension:dimension_star2");require(!DimensionMeleeInput.matches(nongun),"Forged NBT on nongun");
        row("exact_namespace_id_and_real_IGun", "negative_variants",6);
        require(mouse(1,1).isCanceled()&&player.melees==1,"RMB press one request");
        aimMode(true);
        for(int i=0;i<600;i++)for(var phase:TickEvent.Phase.values()){
            var tick=new TickEvent.ClientTickEvent(phase);
            DimensionMeleeInput.beforeTick(tick);AimKey.onAimHoldingPreInput(tick);DimensionMeleeInput.afterTick(tick);
            require(!player.aim,"Hold loop acquired ADS");
        }
        require(mouse(1,2).isCanceled()&&mouse(1,0).isCanceled()&&player.melees==1,"Held/repeat/release repeated melee");
        require(mouse(1,1).isCanceled()&&player.melees==2,"Second physical press");
        row("RMB_press_hold_repeat_release","native_tick_phase_events",1200,"production_tick_subscriber_calls",2400,"native_AimKey_holding_calls",1200,"ordered_game_ticks",600,"wall_clock_time_advance_tested",false,"first_press_requests",1,"second_press_requests",1);
        for(String gate:List.of("GUI","overlay","paused","unfocused","ungrabbed","dead","spectator","no_level","no_player")){
            reset();switch(gate){
                case "GUI"->mc.screen=(Screen)U.allocateInstance(TestScreen.class);
                case "overlay"->field(Minecraft.class,"overlay").set(mc,U.allocateInstance(TestOverlay.class));
                case "paused"->field(Minecraft.class,"pause").setBoolean(mc,true);
                case "unfocused"->field(Minecraft.class,"windowActive").setBoolean(mc,false);
                case "ungrabbed"->field(MouseHandler.class,"mouseGrabbed").setBoolean(mc.mouseHandler,false);
                case "dead"->player.alive=false;case "spectator"->player.spectator=true;
                case "no_level"->mc.level=null;case "no_player"->mc.player=null;
            }
            for(int action:new int[]{1,2,0})require(!mouse(1,action).isCanceled()&&player.melees==0,"Environment gate "+gate);
            row("environment_"+gate,"actions",3);
        }
        for(var state:ReloadState.StateType.values()){
            reset();player.reload.setStateType(state);
            require(mouse(1,1).isCanceled()&&player.melees==(state.isReloading()?0:1),"Reload gate "+state);
            row("reload_"+state,"requests",player.melees);
        }
        for(String gate:List.of("draw","bolt","cooldown")){
            reset();if(gate.equals("draw"))player.draw=1;else if(gate.equals("bolt"))player.bolting=true;else player.meleeCooldown=1;
            require(mouse(1,1).isCanceled()&&player.melees==0,"Action gate "+gate);row("action_"+gate);
        }
        reset();player.reload=null;require(mouse(1,1).isCanceled()&&player.melees==1,"Null sync state accepted");row("null_reload_state");
        for(int button:new int[]{0,2,3,4}){reset();player.aim=true;AimKey.AIM_KEY.setDown(true);require(!mouse(button,1).isCanceled()&&player.melees==0&&player.aim&&AimKey.AIM_KEY.isDown(),"Other mouse button changed");}row("other_mouse_buttons","buttons",4);
        for(ItemStack stack:List.of(foreign,ItemStack.EMPTY,nongun)){
            reset();player.held=stack;player.aim=true;AimKey.AIM_KEY.setDown(true);
            require(!mouse(1,1).isCanceled()&&player.melees==0,"Foreign mouse affected");
            DimensionMeleeInput.beforeTick(new TickEvent.ClientTickEvent(TickEvent.Phase.START));DimensionMeleeInput.afterTick(new TickEvent.ClientTickEvent(TickEvent.Phase.END));
            require(player.aim&&AimKey.AIM_KEY.isDown(),"Foreign aim affected");
        }row("foreign_items_preserved","items",3);
        annotation("beforeTick",TickEvent.ClientTickEvent.class,EventPriority.HIGHEST);annotation("afterTick",TickEvent.ClientTickEvent.class,EventPriority.LOWEST);annotation("mouse",InputEvent.MouseButton.Pre.class,EventPriority.HIGHEST);
        require(AimKey.class.getMethod("onAimHoldingPreInput",TickEvent.ClientTickEvent.class).getAnnotation(SubscribeEvent.class).priority()==EventPriority.NORMAL,"Native aim priority changed");
        int nativeAimTicks=0;
        for(boolean hold:new boolean[]{true,false})for(var phase:TickEvent.Phase.values()){
            reset();aimMode(hold);player.aim=true;AimKey.AIM_KEY.setDown(true);
            var tick=new TickEvent.ClientTickEvent(phase);DimensionMeleeInput.beforeTick(tick);require(!player.aim&&!AimKey.AIM_KEY.isDown(),"Highest clears old ADS");
            AimKey.onAimHoldingPreInput(tick);nativeAimTicks++;require(!player.aim,"Native HOLD handler reenabled ADS");
            // A native Post handler called directly demonstrates what would
            // happen without canceled Pre. LOWEST also clears any late ADS.
            // Real vanilla mouse handling sets KeyMapping down before Post.
            // The 1.2 dispatcher consumes this state in HOLD mode.
            AimKey.AIM_KEY.setDown(true);nativeMousePost(1,1);require(player.aim,"Positive control native Post did not aim");
            DimensionMeleeInput.afterTick(tick);require(!player.aim&&!AimKey.AIM_KEY.isDown(),"Lowest failed to clear late ADS");
            int old=player.melees;var pre=mouse(1,1);if(!pre.isCanceled())nativeMousePost(1,1);
            require(pre.isCanceled()&&player.melees==old+1&&!player.aim,"RMB chain duplicated/melee ADS");
            row("ADS_"+(hold?"HOLD":"TOGGLE")+"_"+phase,"native_NORMAL_ticks",1,"native_Post_positive_control",true,"Pre_canceled_Post_skipped",true);
        }
        // Existing V binds both native melee and zoom. With this gun forced
        // out of ADS, invoking both real native handlers must request one melee
        // and never enter ZoomKey's network-send path (no connection exists).
        reset();aimMode(true);
        require(MeleeKey.MELEE_KEY.matches(86,0)&&ZoomKey.ZOOM_KEY.matches(86,0),"Native V defaults changed");
        for(int action:new int[]{1,2,0})nativeKey(new InputEvent.Key(86,0,action,0));
        require(player.melees==1&&!player.aim,"V native melee/zoom route");row("existing_V_melee_zoom","melee_requests",1,"zoom_network_path_entered",false,"repeat_release_requests",0);
        require(keyCount==((Map<?,?>)field(KeyMapping.class,"ALL").get(null)).size(),"Production introduced new binding");
        for(var k:keys)require(savedKeys.get(k.getName()).equals(k.saveString()),"Production rebound "+k.getName());
        row("no_new_or_changed_key_mapping","existing_mapping_count",keyCount,"keys",savedKeys);
        var report=new LinkedHashMap<String,Object>();report.put("passed",true);report.put("results",cases);report.put("native_aim_holding_calls",nativeAimTicks);report.put("live_client_tested",false);report.put("forge_event_bus_dispatch_executed",false);
        report.put("native_press_dispatch",nativeInput==null?"legacy individual handlers":"TaCZ 1.2 GunInputHandler; actual PRESS/RELEASE filtering");
        report.put("boundary","Production subscribers run directly on genuine Forge event objects. Real Minecraft/MouseHandler getters and native TaCZ AimKey/MeleeKey/ZoomKey logic execute. Unsafe allocated MC/LocalPlayer/ClientLevel host has no initialized world/window/network; only fixture player main hand/alive/spectator, aim and melee-call counters/synchronized state accessors are supplied. QA ASM bridge models two independent TaCZ mixin interfaces and throws on all unused gameplay calls. Native Forge KeyMapping implementation is used. KeyConfig HOLD/TOGGLE uses an in-memory genuine ForgeConfigSpec and public set(); no config save. Annotation priorities are reflected and method order reproduced, not ModLauncher eventbus dispatch. 600 ordered game-tick fixtures run both START/END phases and actual native HOLD poll (1200 calls); they do not advance real gameplay timers. Physical mouse callback/GLFW/network/server hit/damage are not executed. One request per physical PRESS follows GLFW action contract; duplicate synthetic PRESS events are not debounced. Foreign gun operator behavior is not replaced.");
        Files.writeString(Path.of(args[0]).resolve("evidence/input_native.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report)+"\n");
        System.out.println("PASS "+cases.size()+" input groups including 1200 native tick phase events");System.exit(0);
    }
}
