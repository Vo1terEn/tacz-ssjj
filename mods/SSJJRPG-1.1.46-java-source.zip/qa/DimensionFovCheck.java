import cn.ssjjdimension.client.DimensionNativeHands;
import com.google.gson.*;
import com.tacz.guns.api.client.other.KeepingItemRenderer;
import com.tacz.guns.client.event.CameraSetupEvent;
import com.tacz.guns.item.ModernKineticGunItem;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.*;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.*;

/** Actual production subscriber, Forge bus priorities and TaCZ FOV handler.
 * Bounded real-type host; no client window, rendering, physical input or world.
 */
public class DimensionFovCheck {
 static sun.misc.Unsafe u;static Minecraft mc;static Hand hand;static Cam camera;
 static class Hand extends ItemInHandRenderer implements KeepingItemRenderer {
  ItemStack item;Hand(){super(null,null,null);}public ItemStack getCurrentItem(){return item;}public void keep(ItemStack s,long n){}
 }
 static class Cam extends Camera {Entity who;public Entity getEntity(){return who;}}
 static Field field(Class<?> c,String n)throws Exception{Field f=c.getDeclaredField(n);f.setAccessible(true);return f;}
 static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
 static ViewportEvent.ComputeFov event(boolean world){return new ViewportEvent.ComputeFov(null,camera,0,70,world);}
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
  Path w=Path.of(args[0]);u=(sun.misc.Unsafe)field(sun.misc.Unsafe.class,"theUnsafe").get(null);
  var mods=net.minecraftforge.fml.ModList.of(List.of(),List.of());var loaded=net.minecraftforge.fml.ModList.class.getDeclaredMethod("setLoadedMods",List.class);loaded.setAccessible(true);loaded.invoke(mods,List.of());
  mc=(Minecraft)u.allocateInstance(Minecraft.class);field(Minecraft.class,"instance").set(null,mc);mc.player=(DimensionInputCheck.Host)u.allocateInstance(DimensionInputCheck.Host.class);
  var dispatcher=(EntityRenderDispatcher)u.allocateInstance(EntityRenderDispatcher.class);hand=(Hand)u.allocateInstance(Hand.class);field(EntityRenderDispatcher.class,"itemInHandRenderer").set(dispatcher,hand);field(Minecraft.class,"entityRenderDispatcher").set(mc,dispatcher);camera=new Cam();camera.who=mc.player;
  field(MappedRegistry.class,"unregisteredIntrusiveHolders").set(BuiltInRegistries.ITEM,new IdentityHashMap<>());field(MappedRegistry.class,"frozen").setBoolean(BuiltInRegistries.ITEM,false);
  var item=Registry.register(BuiltInRegistries.ITEM,new ResourceLocation("dimensionqa:fovgun"),new ModernKineticGunItem());var target=new ItemStack(item);item.setGunId(target,new ResourceLocation(args.length>1?args[1]:"ssjj_dimension:dimension_star2"));var foreign=new ItemStack(item);item.setGunId(foreign,new ResourceLocation("ssjj_dimension:other"));hand.item=target;
  ResourceManager resources=(ResourceManager)Proxy.newProxyInstance(DimensionFovCheck.class.getClassLoader(),new Class<?>[]{ResourceManager.class},(p,m,a)->{
   if(m.getName().equals("open")){require(a[0].toString().equals("ssjj_dimension:view_calibration.json"),"Calibration resource ID");return Files.newInputStream(w.resolve("pack/assets/ssjj_dimension/view_calibration.json"));}throw new AssertionError("Unexpected resource access "+m);
  });DimensionNativeHands.read(resources);
  double expected=JsonParser.parseString(Files.readString(w.resolve("pack/assets/ssjj_dimension/view_calibration.json"))).getAsJsonObject().get("fitted_vertical_fov_degrees").getAsDouble();
  require(DimensionNativeHands.class.getMethod("fov",ViewportEvent.ComputeFov.class).getAnnotation(SubscribeEvent.class).priority()==EventPriority.LOWEST,"Final weapon-local priority");
  // ModLauncher normally inserts event constructors. Prime the untransformed
  // offline event's native parent-list cache, without replacing the bus.
  var lists=EventListenerHelper.class.getDeclaredMethod("getListenerListInternal",Class.class,boolean.class);lists.setAccessible(true);lists.invoke(null,ViewportEvent.class,true);lists.invoke(null,ViewportEvent.ComputeFov.class,true);
  IEventBus bus=BusBuilder.builder().build();
  // Use the actual native handler and a normal-priority final-value contender.
  // The contender makes event ordering deterministic without a dynamics clock.
  bus.addListener(EventPriority.NORMAL,false,ViewportEvent.ComputeFov.class,(ViewportEvent.ComputeFov e)->{CameraSetupEvent.applyGunModelFovModifying(e);if(!e.usedConfiguredFov())e.setFOV(70);});bus.register(DimensionNativeHands.class);
  List<Map<String,Object>> rows=new ArrayList<>();
  for(int i=0;i<1200;i++){var e=event(false);bus.post(e);require(Math.abs(e.getFOV()-expected)<1e-10,"Model FOV overwritten");}
  rows.add(Map.of("case","actual_Forge_bus_and_TaCZ_handler_1200_events","final_model_fov",expected,"passed",true));
  var world=event(true);bus.post(world);require(world.getFOV()==70,"World FOV changed");rows.add(Map.of("case","world_FOV_preserved","passed",true));
  hand.item=foreign;var other=event(false);bus.post(other);require(other.getFOV()==70,"Other gun changed");hand.item=new ItemStack(Items.STICK);other=event(false);bus.post(other);require(other.getFOV()==70,"Nongun changed");hand.item=target;camera.who=null;other=event(false);bus.post(other);require(other.getFOV()==70,"Foreign camera changed");
  rows.add(Map.of("case","other_gun_nongun_foreign_camera_preserved","passed",true));camera.who=mc.player;
  // Former HIGHEST order: a later normal handler overwrites calibration.
  IEventBus old=BusBuilder.builder().build();old.addListener(EventPriority.HIGHEST,false,ViewportEvent.ComputeFov.class,DimensionNativeHands::fov);old.addListener(EventPriority.NORMAL,false,ViewportEvent.ComputeFov.class,(ViewportEvent.ComputeFov e)->e.setFOV(70));var negative=event(false);old.post(negative);require(negative.getFOV()!=expected,"Priority negative control ineffective");
  Map<String,Object> result=new LinkedHashMap<>();result.put("passed",true);result.put("cases",rows);result.put("actual_resource_reload_read",true);result.put("old_priority_negative_control_rejected",true);result.put("actual_Forge_event_bus",true);result.put("native_TaCZ_model_FOV_handler_executed",true);result.put("normal_priority_contender_used",true);result.put("live_client_test",false);result.put("boundary","Actual production resource read/subscriber and real Forge dispatch plus TaCZ handler. Unsafe bounded Minecraft/renderer/player host and deterministic 70-degree normal-priority contender; no window, GPU or full-client observation. Screenshot projection is an inference, not proof of a specific overriding subscriber.");Files.writeString(w.resolve("evidence/fov_event_check.json"),new GsonBuilder().setPrettyPrinting().create().toJson(result));System.out.println("PASS native FOV event, real Forge ordering, scope and world-FOV guards");System.exit(0);
 }
}
