import cn.ssjjdimension.client.DimensionSkinAnimation;
import com.google.gson.*;
import com.tacz.guns.api.client.animation.*;
import com.tacz.guns.api.client.animation.statemachine.*;
import com.tacz.guns.api.vmlib.*;
import com.tacz.guns.client.animation.statemachine.GunAnimationStateContext;
import com.tacz.guns.client.model.*;
import com.tacz.guns.client.renderer.item.GunItemRendererWrapper;
import com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile;
import com.tacz.guns.client.resource.pojo.model.*;
import com.tacz.guns.item.ModernKineticGunItem;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.JsePlatform;

/** Real native tryInit/needReInit, Lua/factory/controllers and model transforms.
 * The renderer host supplies neutral context inputs and selected state-machine
 * lookup, avoiding client services and GL. No substitute animation APIs.
 */
public final class DimensionSkinSwitchCheck {
 static sun.misc.Unsafe U;static Path a;static List<ObjectAnimation> animations;static LuaTable script;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static Field f(Class<?> c,String n)throws Exception{var x=c.getDeclaredField(n);x.setAccessible(true);return x;}
 public static class Inputs extends GunAnimationStateContext {
  int starts;
  @Override public void runAnimation(String n,int t,boolean b,int p,float d){starts++;super.runAnimation(n,t,b,p,d);}
  public boolean hasBulletInBarrel(){return false;}public int getAmmoCount(){return 12;}
  public boolean isOverHeat(){return false;}public float getAimingProgress(){return 0;}public boolean isAiming(){return false;}public boolean isCharging(){return false;}
  public boolean isOnGround(){return true;}public boolean shouldSlide(){return false;}
  public boolean isInputUp(){return false;}public boolean isInputDown(){return false;}public boolean isInputLeft(){return false;}public boolean isInputRight(){return false;}
  public float getWalkDist(){return 0;}public void anchorWalkDist(){}public long getCurrentTimestamp(){return 0;}public long getShootCoolDown(){return 0;}
  public float getPutAwayTime(){return .25f;}public void popShellFrom(int port){}
 }
 public static class HostRenderer extends GunItemRendererWrapper {
  LuaAnimationStateMachine<GunAnimationStateContext> chosen;
  @Override public LuaAnimationStateMachine<GunAnimationStateContext> getStateMachine(ItemStack s){return chosen;}
  @Override public GunAnimationStateContext initContext(ItemStack s,Player p,float t){return new Inputs();}
 }
 static class Rig {
  BedrockGunModel model;AnimationController controller;HostRenderer renderer;
  Rig(String key)throws Exception{
   model=new BedrockGunModel(DimensionNativeCheck.GSON.fromJson(Files.readString(a.resolve("geo_models/gun/"+key+"_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);
   controller=new AnimationController(animations,model);renderer=(HostRenderer)U.allocateInstance(HostRenderer.class);
   renderer.chosen=new LuaStateMachineFactory<GunAnimationStateContext>().setController(controller).setLuaScripts(script).build();
  }
  void render(){model.cleanAnimationTransform();if(controller.getUpdatingTrackArray()!=null)for(int t:controller.getUpdatingTrackArray()){var r=controller.getAnimation(t);if(r!=null){r.pause();r.setProgressNs(0);}}controller.update();}
  Matrix4f arm(String bone){return DimensionNativeCheck.node(model,bone);}
 }
 public static void main(String[]args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
  var mods=net.minecraftforge.fml.ModList.of(List.of(),List.of());var loaded=net.minecraftforge.fml.ModList.class.getDeclaredMethod("setLoadedMods",List.class);loaded.setAccessible(true);loaded.invoke(mods,List.of());
  U=(sun.misc.Unsafe)f(sun.misc.Unsafe.class,"theUnsafe").get(null);var mc=(net.minecraft.client.Minecraft)U.allocateInstance(net.minecraft.client.Minecraft.class);f(net.minecraft.client.Minecraft.class,"instance").set(null,mc);Path w=Path.of(args[0]);a=w.resolve("pack/assets/ssjj_dimension");
  JsonObject anim=DimensionNativeCheck.read(a.resolve("animations/dimension_star2.animation.json"));for(var e:anim.getAsJsonObject("animations").entrySet())e.getValue().getAsJsonObject().remove("sound_effects");animations=Animations.createAnimationFromBedrock(DimensionNativeCheck.GSON.fromJson(anim,BedrockAnimationFile.class));
  Globals g=JsePlatform.standardGlobals();new LuaAnimationConstant().install(g);new LuaGunAnimationConstant().install(g);
  g.get("package").get("loaded").set("tacz_default_state_machine",g.load(Files.readString(w.resolve("build/native_dependencies/official_default_state_machine.lua"))).call());script=g.load(Files.readString(a.resolve("scripts/dimension_star2_state_machine.lua"))).call().checktable();
  f(MappedRegistry.class,"unregisteredIntrusiveHolders").set(BuiltInRegistries.ITEM,new IdentityHashMap<>());f(MappedRegistry.class,"frozen").setBoolean(BuiltInRegistries.ITEM,false);
  var item=Registry.register(BuiltInRegistries.ITEM,new ResourceLocation("dimensionqa:skin_gun"),new ModernKineticGunItem());Player player=(Player)U.allocateInstance(net.minecraft.server.level.ServerPlayer.class);
  var rows=new ArrayList<Map<String,Object>>();int cases=0;double maxError=0,minNegative=Double.POSITIVE_INFINITY;Rig previous=null;
  for(String gun:cn.ssjjdimension.DimensionScopes.GUNS)for(String skin:new String[]{"frozen","neon","royal",""}){
   String key=gun+(skin.isEmpty()?"":"_"+skin);var render=new ItemStack(item);item.setGunId(render,new ResourceLocation("ssjj_dimension",gun));
   render.getOrCreateTag().putString("GunDisplayId","ssjj_dimension:"+key+"_display");var held=render.copy();held.getOrCreateTag().putBoolean("InventoryHandoff",true);
   check(!ItemStack.matches(render,held),"Negative control must fail native full-NBT equality");
   Rig control=new Rig(key),negative=new Rig(key),actual=negative;control.renderer.tryInit(render,player,0);control.render();
   // Execute the installed native adapter: once drawn, updateItem to a new
   // display cannot call tryInit again. No GL/sound services are used because
   // the explicit MC host has no player; HostRenderer supplies neutral context.
   Rig before=new Rig(gun);var original=new ItemStack(item);item.setGunId(original,new ResourceLocation("ssjj_dimension",gun));
   var adapter=before.renderer.createAnimationInstance(original,null);adapter.triggerDraw();check(before.renderer.chosen.isInitialized(),"Native adapter did not draw original");
   original.setTag(render.getTag().copy());before.renderer.chosen=negative.renderer.chosen;adapter.updateItem(original);adapter.triggerDraw();check(adapter.currentItem()==original&&!negative.renderer.chosen.isInitialized(),"Native one-shot adapter negative control missing");negative.render();actual.renderer=before.renderer;
   double gap=DimensionNativeCheck.difference(control.arm("lefthand"),negative.arm("lefthand"));minNegative=Math.min(minNegative,gap);check(gap>.1,"Cold skin did not expose missing hand pose");
   check(DimensionSkinAnimation.prepare(render,held,actual.renderer,player,0),"Cold display adapter fallback missing");
   // Match TaCZ: previous display exits after our HIGHEST-priority preparation.
   if(previous!=null&&previous.renderer.chosen.isInitialized())previous.renderer.chosen.exit();
   check(actual.renderer.chosen.isInitialized(),"Native renderer did not initialize state machine");actual.render();
   double error=0;for(String bone:new String[]{"lefthand","righthand","Dummy001","WeaponAnchor"})error=Math.max(error,DimensionNativeCheck.difference(control.arm(bone),actual.arm(bone)));maxError=Math.max(maxError,error);check(error<1e-5,"First frame differs from normal native initialized draw");
   var context=(Inputs)actual.renderer.chosen.getContext();int starts=context.starts;
   for(int frame=0;frame<30;frame++)check(!DimensionSkinAnimation.prepare(render,held,actual.renderer,player,0),"Warm display restarted");check(starts==context.starts,"Warm draw/action was reset");
   actual.renderer.chosen.setExitingTime(1000);actual.renderer.chosen.exit();check(!DimensionSkinAnimation.prepare(render,held,actual.renderer,player,0),"Outgoing put-away display resurrected");
   // Same-item display changes need the compensation even with equal NBT snapshots.
   Rig equal=new Rig(key);check(DimensionSkinAnimation.prepare(render,render.copy(),equal.renderer,player,0),"Same-stack cold display not initialized");
   Rig guards=new Rig(key);equal=guards;var foreign=held.copy();item.setGunId(foreign,new ResourceLocation("other",gun));check(!DimensionSkinAnimation.prepare(render,foreign,equal.renderer,player,0),"Foreign gun matched");
   var different=held.copy();different.getOrCreateTag().putString("GunDisplayId","other:display");check(!DimensionSkinAnimation.prepare(render,different,equal.renderer,player,0),"Outgoing skin matched");
   check(render.getTag().size()+1==held.getTag().size()&&held.getTag().getBoolean("InventoryHandoff"),"Handoff modified NBT");
   rows.add(Map.of("profile",key,"cold_without_fallback_arm_matrix_error",gap,"native_first_frame_error",error,"warm_frames_without_reset",30,"put_away_guard",true));cases++;previous=control;
  }
  var ann=DimensionSkinAnimation.class.getMethod("prepareDimensionSkinHandFrame",net.minecraftforge.client.event.RenderHandEvent.class).getAnnotation(net.minecraftforge.eventbus.api.SubscribeEvent.class);check(ann.priority()==net.minecraftforge.eventbus.api.EventPriority.HIGHEST&&!ann.receiveCanceled(),"Wrong event order");
  var report=new LinkedHashMap<String,Object>();report.put("passed",true);report.put("profiles",rows);report.put("first_change_cases",cases);report.put("maximum_native_first_frame_matrix_error",maxError);report.put("minimum_negative_control_arm_matrix_error",minNegative);report.put("no_inventory_or_gameplay_writes",true);report.put("live_client_test",false);report.put("boundary","Actual installed AnimateGeoItemRenderer.createAnimationInstance/triggerDraw/updateItem adapter reproduces first-only init: drawn flag remains true after a display change and the new native state machine stays cold. Production prepare yields the same first frame as normal native tryInit, with equal and differing NBT snapshots. Host renderer selects actual machines and supplies neutral context inputs; explicit MC host has no player for native draw sound guard. No GL or full-client dispatch.");Files.writeString(w.resolve("evidence/skin_switch_native.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));System.out.println("PASS first skin change / unload profiles="+cases+" max native first frame error="+maxError+" negative="+minNegative);System.exit(0);
 }
}
