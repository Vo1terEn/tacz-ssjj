import com.google.gson.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.tacz.guns.api.client.animation.*;
import com.tacz.guns.client.model.*;
import com.tacz.guns.client.resource.pojo.animation.bedrock.*;
import com.tacz.guns.client.resource.pojo.model.*;
import com.tacz.guns.client.resource.serialize.*;
import java.lang.Math;
import java.nio.file.*;
import java.util.*;
import org.joml.*;

/** Actual serialized TaCZ animations versus independently sampled raw source.
 * Does not invoke player skin services, Forge client entry, or GL rendering.
 */
public final class DimensionNativeCheck {
    static final Gson GSON=new GsonBuilder()
        .registerTypeAdapter(CubesItem.class,new CubesItem.Deserializer())
        .registerTypeAdapter(Vector3f.class,new Vector3fSerializer())
        .registerTypeAdapter(AnimationKeyframes.class,new AnimationKeyframesSerializer())
        .registerTypeAdapter(SoundEffectKeyframes.class,new SoundEffectKeyframesSerializer()).create();
    static JsonObject read(Path path)throws Exception{return JsonParser.parseString(Files.readString(path)).getAsJsonObject();}
    static Matrix4f matrix(JsonArray rows){float[] result=new float[16];for(int r=0;r<4;r++)for(int c=0;c<4;c++)result[c*4+r]=rows.get(r).getAsJsonArray().get(c).getAsFloat();return new Matrix4f().set(result);}
    static JsonArray rows(Matrix4f m){JsonArray result=new JsonArray();for(int r=0;r<4;r++){JsonArray row=new JsonArray();for(int c=0;c<4;c++)row.add(m.get(c,r));result.add(row);}return result;}
    static Vector3f vec(JsonArray a){return new Vector3f(a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat());}
    static Matrix4f node(BedrockGunModel model,String name){PoseStack p=new PoseStack();model.getRootNode().translateAndRotateAndScale(p);model.getNode(name).translateAndRotateAndScale(p);for(int r=0;r<3;r++)for(int c=0;c<3;c++)require(Float.isFinite(p.last().normal().get(c,r)),"Nonfinite native normal "+name);return new Matrix4f(p.last().pose());}
    static void pause(AnimationController c,int track,double time){var animation=c.getAnimation(track);animation.pause();animation.setProgressNs(Math.round(time*1e9));}
    static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
    static double difference(Matrix4f a,Matrix4f b){double error=0;for(int r=0;r<4;r++)for(int c=0;c<4;c++)error=Math.max(error,Math.abs(a.get(c,r)-b.get(c,r)));return error;}
    static double pointError(Matrix4f actual,Matrix4f expected,Vector3f p){return actual.transformPosition(new Vector3f(p)).distance(expected.transformPosition(new Vector3f(p)));}
    static boolean additive(String name){return name.equals("shoot")||name.equals("walk")||name.equals("run")||name.equals("aim_walk")||name.equals("aim_run");}
    public static void main(String[] args)throws Exception{
        Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
        Path work=Path.of(args[0]),assets=work.resolve("pack/assets/ssjj_dimension");
        JsonObject animationJson=read(assets.resolve("animations/dimension_star2.animation.json"));
        int isolatedSounds=0;for(var entry:animationJson.getAsJsonObject("animations").entrySet())if(entry.getValue().getAsJsonObject().remove("sound_effects")!=null)isolatedSounds++;
        var animations=Animations.createAnimationFromBedrock(GSON.fromJson(animationJson,BedrockAnimationFile.class));
        BedrockGunModel model=new BedrockGunModel(GSON.fromJson(Files.readString(assets.resolve("geo_models/gun/dimension_star2_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);
        JsonObject reference=read(work.resolve("evidence/native_reference_samples.json"));
        JsonObject armFixture=read(work.getParent().resolve("parasite_video_match_20261104/evidence/native_hand_scale/neutral_native_arm_geometry.json"));
        require(armFixture.get("status").getAsString().equals("PASS_ACTUAL_NEUTRAL_PLAYER_ARM_GEOMETRY"),"No actual setupAnim fixture");
        Map<String,JsonArray> bodyVertices=new LinkedHashMap<>();
        Path mesh=assets.resolve("source_mesh.json");
        Path bodyGeometry=Files.exists(mesh)?mesh:work.resolve("evidence/raw_gun_local_geometry.json");
        for(JsonElement element:read(bodyGeometry).getAsJsonArray("parts")){
            JsonObject part=element.getAsJsonObject();bodyVertices.put(part.get("bone").getAsString(),part.getAsJsonArray("positions"));
        }
        JsonObject clips=new JsonObject(),matrixErrors=new JsonObject(),worstMatrix=new JsonObject();JsonArray capturedFrames=new JsonArray();
        double maxMatrix=0,maxBody=0,maxArms=0,maxCap=0,maxScale=0,worstFrame=-1;long bodyCount=0,armCount=0;int frameCount=0;
        String active="";AnimationController controller=null;JsonObject worst=new JsonObject();
        for(JsonElement value:reference.getAsJsonArray("samples")){
            JsonObject frame=value.getAsJsonObject();String name=frame.get("animation").getAsString();double time=frame.get("time").getAsDouble();
            if(!name.equals(active)){
                controller=new AnimationController(animations,model);active=name;
                controller.runAnimation(2,additive(name)?"static_idle":name,ObjectAnimation.PlayType.PLAY_ONCE_HOLD,0);controller.setBlending(2,false);
                if(additive(name)){
                    pause(controller,2,0);controller.runAnimation(5,name,ObjectAnimation.PlayType.PLAY_ONCE_HOLD,0);controller.setBlending(5,true);controller.setUpdatingTrackArray(List.of(2,5));
                }else controller.setUpdatingTrackArray(List.of(2));
            }
            pause(controller,additive(name)?5:2,time);model.cleanAnimationTransform();controller.update();
            JsonObject actualNodes=new JsonObject();double frameBody=0,frameArms=0;
            for(var entry:frame.getAsJsonObject("matrices").entrySet()){
                String bone=entry.getKey();Matrix4f actual=node(model,bone),expected=matrix(entry.getValue().getAsJsonArray());
                expected.m31(expected.m31()+1.5f);Vector3f expectedScale=vec(frame.getAsJsonObject("scales").getAsJsonArray(bone));expected.scale(expectedScale);
                for(int r=0;r<4;r++)for(int c=0;c<4;c++)require(Float.isFinite(actual.get(c,r)),"Nonfinite native pose "+name+"/"+bone+" @ "+time);
                double matrixError=difference(actual,expected);
                if(matrixError>maxMatrix){worstMatrix=new JsonObject();worstMatrix.addProperty("animation",name);worstMatrix.addProperty("time",time);worstMatrix.addProperty("bone",bone);worstMatrix.addProperty("error",matrixError);}
                maxMatrix=Math.max(maxMatrix,matrixError);matrixErrors.addProperty(bone,Math.max(matrixError,matrixErrors.has(bone)?matrixErrors.get(bone).getAsDouble():0));actualNodes.add(bone,rows(actual));
                var part=model.getNode(bone);maxScale=Math.max(maxScale,Math.max(Math.abs(part.xScale-expectedScale.x),Math.max(Math.abs(part.yScale-expectedScale.y),Math.abs(part.zScale-expectedScale.z))));
                if(bodyVertices.containsKey(bone))for(JsonElement p:bodyVertices.get(bone)){
                    double error=pointError(actual,expected,vec(p.getAsJsonArray()));maxBody=Math.max(maxBody,error);frameBody=Math.max(frameBody,error);bodyCount++;
                }
                if(bone.equals("lefthand")||bone.equals("righthand")){
                    String side=bone.startsWith("left")?"left":"right";
                    JsonArray delta=reference.getAsJsonObject("slim_callback_translation").getAsJsonArray(side.equals("left")?"L":"R");
                    for(String variant:List.of("default","slim"))for(String piece:List.of(side,side+"_sleeve")){
                        JsonObject cube=armFixture.getAsJsonObject("variants").getAsJsonObject(variant).getAsJsonObject(piece);
                        Vector3f correction=variant.equals("slim")?vec(delta):new Vector3f();
                        for(JsonElement p:cube.getAsJsonArray("vertices")){
                            double error=pointError(actual,expected,vec(p.getAsJsonArray()).add(correction));
                            maxArms=Math.max(maxArms,error);frameArms=Math.max(frameArms,error);armCount++;
                        }
                        Vector3f cap=vec(cube.getAsJsonArray("distal_cap")).add(correction);
                        maxCap=Math.max(maxCap,pointError(actual,expected,cap));
                    }
                    if(frame.has("landmarks")){
                        Vector3f contact=vec(frame.getAsJsonObject("landmarks").getAsJsonObject(side).getAsJsonArray("contact")).add(0,1.5f,0);
                        Vector3f cap=vec(armFixture.getAsJsonObject("variants").getAsJsonObject("default").getAsJsonObject(side).getAsJsonArray("distal_cap"));
                        double error=actual.transformPosition(cap).distance(contact);maxCap=Math.max(maxCap,error);
                    }
                }
            }
            JsonObject clip=clips.has(name)?clips.getAsJsonObject(name):new JsonObject();
            int count=clip.has("frames")?clip.get("frames").getAsInt():0;
            clip.addProperty("frames",count+1);clip.addProperty("maximum_body_vertex_error_blocks",Math.max(frameBody,clip.has("maximum_body_vertex_error_blocks")?clip.get("maximum_body_vertex_error_blocks").getAsDouble():0));
            clip.addProperty("maximum_arm_skin_sleeve_vertex_error_blocks",Math.max(frameArms,clip.has("maximum_arm_skin_sleeve_vertex_error_blocks")?clip.get("maximum_arm_skin_sleeve_vertex_error_blocks").getAsDouble():0));clips.add(name,clip);
            if(Math.max(frameBody,frameArms)>worstFrame){worstFrame=Math.max(frameBody,frameArms);worst=new JsonObject();worst.addProperty("animation",name);worst.addProperty("time",time);worst.addProperty("frame_body_error",frameBody);worst.addProperty("frame_arm_error",frameArms);}
            JsonObject captured=new JsonObject();captured.addProperty("animation",name);captured.addProperty("time",time);captured.add("native_node_matrices_with_scale_and_root_y",actualNodes);capturedFrames.add(captured);frameCount++;
        }
        boolean passed=maxBody<.002&&maxArms<.002&&maxCap<.002&&maxScale<.001;
        JsonObject report=new JsonObject();report.addProperty("status",passed?"PASS_NATIVE_SERIALIZED_SCALED_ARMS":"FAIL_NATIVE_SERIALIZED_SCALED_ARMS");report.addProperty("passed",passed);
        report.addProperty("frames",frameCount);report.addProperty("body_mesh_present",Files.exists(mesh));report.addProperty("body_vertex_source",bodyGeometry.toString());report.addProperty("body_vertices_checked",bodyCount);report.addProperty("default_slim_skin_sleeve_vertices_checked",armCount);
        report.addProperty("maximum_native_matrix_component_error",maxMatrix);report.addProperty("maximum_body_vertex_error_blocks",maxBody);report.addProperty("maximum_arm_skin_sleeve_vertex_error_blocks",maxArms);report.addProperty("maximum_distal_cap_contact_error_blocks",maxCap);report.addProperty("maximum_scale_component_error",maxScale);
        report.add("matrix_error_by_bone",matrixErrors);report.add("worst_matrix_sample",worstMatrix);
        report.addProperty("actual_tacz_animation_controller",true);report.addProperty("shoot_idle_additive_composition_tested",true);report.addProperty("actual_post_setup_anim_arm_and_sleeve_geometry",true);
        report.addProperty("boundary","Serialized production animation and geo parsed by actual TaCZ BedrockGunModel and AnimationController. All actual post-setupAnim default/slim arm+sleeve vertices transformed through actual animated node matrices; known local slim correction is applied analytically, not via a real client player. Skin services, full native camera chain, live player callback and production mesh consumer emission are separate tests.");
        report.addProperty("live_client_tested",false);report.addProperty("sound_playback_tested",false);report.addProperty("sound_metadata_removed_in_memory",isolatedSounds);report.add("clips",clips);report.add("worst_sample",worst);
        Gson pretty=new GsonBuilder().setPrettyPrinting().create();Files.writeString(work.resolve("evidence/native_serialized_animation_check.json"),pretty.toJson(report));
        Files.writeString(work.resolve("evidence/native_serialized_samples.json"),GSON.toJson(capturedFrames));System.out.println(report);System.exit(passed?0:1);
    }
}
