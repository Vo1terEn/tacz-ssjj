import com.google.gson.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.tacz.guns.api.client.animation.*;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.client.event.FirstPersonRenderGunEvent;
import com.tacz.guns.client.model.*;
import com.tacz.guns.client.renderer.item.GunItemRendererWrapper;
import com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile;
import com.tacz.guns.client.resource.pojo.model.*;
import com.tacz.guns.util.math.MathUtil;
import java.lang.reflect.Method;
import java.lang.Math;
import java.nio.file.*;
import java.util.*;
import org.joml.*;

/** Actual TaCZ private positioning inverse + all four actual view blends. */
public final class DimensionViewCheck {
 static final Gson G=DimensionNativeCheck.GSON;
 static Method fixedPosition()throws Exception{
  Method method;
  try{method=GunItemRendererWrapper.class.getDeclaredMethod("applyPositioningNodeTransform",List.class,PoseStack.class,Vector3f.class);}
  catch(NoSuchMethodException moved){method=Class.forName("com.tacz.guns.client.renderer.item.GunItemTransforms").getDeclaredMethod("applyPositioningNode",List.class,PoseStack.class,Vector3f.class);}
  method.setAccessible(true);return method;
 }
 static Matrix4f inverse(Method m,List<?> path)throws Exception{return new Matrix4f((Matrix4f)m.invoke(null,path));}
 static Matrix4f chain(Method m,BedrockGunModel model,float aim,float opening)throws Exception{
  Matrix4f blend=new Matrix4f();
  MathUtil.applyMatrixLerp(blend,inverse(m,model.getIdleSightPath()),blend,1-opening);
  MathUtil.applyMatrixLerp(blend,inverse(m,model.getIronSightPath()),blend,(1-opening)*aim);
  MathUtil.applyMatrixLerp(blend,inverse(m,model.getRefitAttachmentViewPath(AttachmentType.NONE)),blend,opening);
  MathUtil.applyMatrixLerp(blend,inverse(m,model.getRefitAttachmentViewPath(AttachmentType.NONE)),blend,opening);
  PoseStack p=new PoseStack();p.translate(0,1.5,0);p.mulPose(Axis.ZP.rotationDegrees(180));p.translate(0,1.5,0);p.mulPoseMatrix(blend);p.translate(0,-1.5,0);return new Matrix4f(p.last().pose());
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
  net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
  Path w=Path.of(args[0]),a=w.resolve("pack/assets/ssjj_dimension");
  BedrockGunModel model=new BedrockGunModel(G.fromJson(Files.readString(a.resolve("geo_models/gun/dimension_star2_geo.json")),BedrockModelPOJO.class),BedrockVersion.NEW);
  JsonObject animation=DimensionNativeCheck.read(a.resolve("animations/dimension_star2.animation.json"));for(var e:animation.getAsJsonObject("animations").entrySet())e.getValue().getAsJsonObject().remove("sound_effects");
  var animations=Animations.createAnimationFromBedrock(G.fromJson(animation,BedrockAnimationFile.class));
  AnimationController controller=new AnimationController(animations,model);controller.runAnimation(2,"static_idle",ObjectAnimation.PlayType.LOOP,0);controller.setBlending(2,false);controller.setUpdatingTrackArray(List.of(2));DimensionNativeCheck.pause(controller,2,0);model.cleanAnimationTransform();controller.update();
  Method method=FirstPersonRenderGunEvent.class.getDeclaredMethod("getPositioningNodeInverse",List.class);method.setAccessible(true);
  JsonObject mesh=DimensionNativeCheck.read(a.resolve("source_mesh.json")),cal=DimensionNativeCheck.read(a.resolve("view_calibration.json"));
  JsonObject views=new JsonObject();JsonArray dumps=new JsonArray();boolean refitVisible=false;double maxHipMatrix=0;double fov=cal.has("fitted_vertical_fov_degrees")?cal.get("fitted_vertical_fov_degrees").getAsDouble():70;
  double tanY=Math.tan(Math.toRadians(fov*.5)),tanX=tanY*1920./1080.;
  for(String view:List.of("hip","ads","refit","fixed","opening025","opening050","opening075")){
   float aim=view.equals("ads")?1:0,opening=view.equals("refit")?1:view.startsWith("opening")?Integer.parseInt(view.substring(7))/100f:0;
   Matrix4f actual=chain(method,model,aim,opening);
   if(view.equals("fixed")){Method fixed=fixedPosition();PoseStack pp=new PoseStack();pp.translate(0,1.5,0);pp.scale(-1,-1,1);fixed.invoke(null,model.getFixedOriginPath(),pp,new Vector3f(1));actual=new Matrix4f(pp.last().pose());actual.m32(actual.m32()-3);}
   JsonObject d=new JsonObject();d.add("complete_wrapper_positioning_matrix_on_native_emitted",DimensionNativeCheck.rows(actual));
   if(view.equals("hip")){
    Matrix4f expected=DimensionNativeCheck.matrix(cal.getAsJsonArray("expected_complete_matrix_on_native_emitted"));maxHipMatrix=DimensionNativeCheck.difference(actual,expected);d.addProperty("source_camera_fitted_oracle_matrix_error",maxHipMatrix);
   }
   double[] lo={1e20,1e20,1e20},hi={-1e20,-1e20,-1e20};int vertices=0,behind=0,outside=0;JsonArray parts=new JsonArray();
   for(JsonElement e:mesh.getAsJsonArray("parts")){
    JsonObject part=e.getAsJsonObject();String bone=part.get("bone").getAsString();Matrix4f transform=new Matrix4f(actual).mul(DimensionNativeCheck.node(model,bone));JsonArray ps=new JsonArray();
    for(JsonElement p:part.getAsJsonArray("positions")){
     Vector3f v=transform.transformPosition(DimensionNativeCheck.vec(p.getAsJsonArray()));for(int i=0;i<3;i++){lo[i]=Math.min(lo[i],v.get(i));hi[i]=Math.max(hi[i],v.get(i));}
     if(v.z>=-.02)behind++;else if(Math.abs(v.x)>-v.z*tanX||Math.abs(v.y)>-v.z*tanY)outside++;
     JsonArray point=new JsonArray();point.add(v.x);point.add(v.y);point.add(v.z);ps.add(point);vertices++;
    }
    JsonObject out=new JsonObject();out.addProperty("bone",bone);out.add("camera_space_positions",ps);parts.add(out);
   }
   d.add("camera_space_minimum",G.toJsonTree(lo));d.add("camera_space_maximum",G.toJsonTree(hi));d.addProperty("body_vertices",vertices);d.addProperty("behind_near_plane_vertices",behind);d.addProperty("outside_configured_fov_vertices",outside);
   if(view.equals("refit")){refitVisible=behind==0&&outside==0;d.addProperty("complete_body_visible",refitVisible);}
   views.add(view,d);JsonObject dump=new JsonObject();dump.addProperty("view",view);dump.add("parts",parts);dumps.add(dump);
  }
  boolean passed=maxHipMatrix<.0001&&refitVisible;JsonObject report=new JsonObject();report.addProperty("status",passed?"PASS_NATIVE_VIEW_CHAIN":"FAIL_NATIVE_VIEW_CHAIN");report.addProperty("passed",passed);report.addProperty("live_client_test",false);report.addProperty("actual_private_positioning_inverse_called",true);report.addProperty("actual_mathutil_blends",4);report.addProperty("wrapper_prefix_reproduced",true);report.addProperty("full_player_item_entry_invoked",false);report.addProperty("maximum_hip_source_camera_matrix_error",maxHipMatrix);report.addProperty("refit_all_body_visible",refitVisible);report.addProperty("verification_vertical_fov_degrees",fov);report.add("views",views);report.addProperty("boundary","TaCZ private inverse and four blend calls execute; vanilla wrapper prefix reproduced. Native root +1.5Y included. No live player, texture manager, light, UI or first-person event entry invoked. ADS shares source camera because source has no ADS animation; candidate reference match is measured separately.");
  Files.createDirectories(w.resolve("evidence/native_view_chain"));Files.writeString(w.resolve("evidence/native_view_chain/stand_camera_vertices.json"),G.toJson(dumps));Files.writeString(w.resolve("evidence/native_view_check.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));System.out.println(report);System.exit(passed?0:1);
 }
}
