import com.google.gson.GsonBuilder;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.sound.GunSoundInstance;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarFile;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** Executes the bridge against each actual TaCZ release, without sound/GL services. */
public final class TaCZSoundCompatCheck {
    private static final String BRIDGE = "cn/ssjjcompat/TaCZSounds";
    private static final String DISPLAY = "com/tacz/guns/client/resource/GunDisplayInstance";
    private static final String GET = "(L" + DISPLAY + ";Ljava/lang/String;)Ljava/lang/Object;";
    private static final String PLAY = "(Lnet/minecraft/world/entity/Entity;Ljava/lang/Object;FFI)Lcom/tacz/guns/client/sound/GunSoundInstance;";
    private static int assertions;

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }

    private static Field field(Class<?> type, String name) throws Exception {
        Field value = type.getDeclaredField(name);
        value.setAccessible(true);
        return value;
    }

    private static Map<String, Object> checkPatchedCaller(Path candidate) throws Exception {
        int[] calls = new int[5];
        try (JarFile jar = new JarFile(candidate.toFile())) {
            for (var entry : Collections.list(jar.entries())) {
                if (!entry.getName().endsWith(".class")) continue;
                boolean darkClient = entry.getName().equals("ssjj/dark/DarkClient.class");
                try (var input = jar.getInputStream(entry)) {
                    new ClassReader(input.readAllBytes()).accept(new ClassVisitor(Opcodes.ASM9) {
                        @Override
                        public MethodVisitor visitMethod(int access, String name, String descriptor,
                                                         String signature, String[] exceptions) {
                            boolean strike = darkClient && name.equals("lambda$strike$2");
                            if (strike) calls[0]++;
                            return new MethodVisitor(Opcodes.ASM9) {
                                @Override
                                public void visitMethodInsn(int opcode, String owner, String method,
                                                            String desc, boolean isInterface) {
                                    if (owner.equals(BRIDGE) && method.equals("getSounds")) {
                                        calls[1]++;
                                        check(strike && opcode == Opcodes.INVOKESTATIC && desc.equals(GET),
                                              "Sound lookup bridge must replace only the original strike call");
                                    }
                                    if (owner.equals(BRIDGE) && method.equals("playClientSound")) {
                                        calls[2]++;
                                        check(strike && opcode == Opcodes.INVOKESTATIC && desc.equals(PLAY),
                                              "Sound playback bridge must replace only the original strike call");
                                    }
                                    if (owner.equals(DISPLAY) && method.equals("getSounds")) calls[3]++;
                                    if (strike && owner.equals("com/tacz/guns/client/sound/SoundPlayManager")
                                               && method.equals("playClientSound")) calls[4]++;
                                }

                                @Override
                                public void visitFrame(int type, int numLocal, Object[] local,
                                                       int numStack, Object[] stack) {
                                    if (!strike || local == null) return;
                                    for (int i = 0; i < numLocal; i++) {
                                        check(!"net/minecraft/resources/ResourceLocation".equals(local[i]),
                                              "Patched strike frame must not narrow SoundData to ResourceLocation");
                                    }
                                }
                            };
                        }
                    }, ClassReader.SKIP_DEBUG);
                }
            }
        }
        check(calls[0] == 1, "Expected exactly one original strike lambda");
        check(calls[1] == 1, "Expected exactly one sound lookup bridge call");
        check(calls[2] == 1, "Expected exactly one sound playback bridge call");
        check(calls[3] == 0, "No obsolete direct GunDisplayInstance.getSounds invocation may remain");
        check(calls[4] == 0, "Strike playback must select the actual release's sound type");
        return Map.of("strike_lambda_count", calls[0], "lookup_bridge_calls", calls[1],
                      "playback_bridge_calls", calls[2], "obsolete_direct_lookup_calls", calls[3],
                      "obsolete_direct_strike_playback_calls", calls[4]);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("candidate.jar report.json");
        Class<?> darkClient = Class.forName("ssjj.dark.DarkClient", false,
                                            TaCZSoundCompatCheck.class.getClassLoader());
        check(Files.isSameFile(Path.of(darkClient.getProtectionDomain().getCodeSource().getLocation().toURI()),
                               Path.of(args[0])), "JVM must verify DarkClient from the actual candidate JAR");
        // Reflection links/verifies all declared methods, including the patched
        // lambda's stack map frames, without invoking DarkClient's initializer.
        Method[] verifiedMethods = darkClient.getDeclaredMethods();
        check(verifiedMethods.length > 0, "JVM did not link the patched DarkClient methods");
        Class<?> bridge = Class.forName("cn.ssjjcompat.TaCZSounds");
        Method lookup = bridge.getMethod("getSounds", GunDisplayInstance.class, String.class);
        Method play = bridge.getMethod("playClientSound", Entity.class, Object.class,
                                       float.class, float.class, int.class);
        check(lookup.getReturnType() == Object.class, "Bridge lookup must retain the actual sound object");
        check(play.getReturnType() == GunSoundInstance.class, "Playback return contract changed");

        Class<?> soundType = GunDisplayInstance.class.getMethod("getSounds", String.class).getReturnType();
        boolean modern = soundType.getName().equals("com.tacz.guns.client.resource.pojo.display.SoundData");
        check(modern || soundType == ResourceLocation.class, "Unexpected TaCZ sound API shape: " + soundType);
        Method nativePlay = Class.forName("com.tacz.guns.client.sound.SoundPlayManager", false,
                                          bridge.getClassLoader())
            .getMethod("playClientSound", Entity.class, soundType, float.class, float.class, int.class);
        check(nativePlay.getReturnType() == GunSoundInstance.class, "Actual native overload is unavailable");

        List<String> handleTypes = new ArrayList<>();
        MethodType expectedGet = MethodType.methodType(Object.class, GunDisplayInstance.class, String.class);
        MethodType expectedPlay = MethodType.methodType(GunSoundInstance.class, Entity.class,
                                                        Object.class, float.class, float.class, int.class);
        for (Field declared : bridge.getDeclaredFields()) {
            if (declared.getType() != MethodHandle.class) continue;
            declared.setAccessible(true);
            MethodHandle handle = (MethodHandle) declared.get(null);
            check(handle != null, "Cached sound handle is null");
            handleTypes.add(handle.type().toString());
        }
        check(handleTypes.contains(expectedGet.toString()), "Cached lookup handle has the wrong signature");
        check(handleTypes.contains(expectedPlay.toString()), "Cached playback handle has the wrong signature");

        sun.misc.Unsafe unsafe = (sun.misc.Unsafe) field(sun.misc.Unsafe.class, "theUnsafe").get(null);
        GunDisplayInstance display = (GunDisplayInstance) unsafe.allocateInstance(GunDisplayInstance.class);
        ResourceLocation heavyId = new ResourceLocation("ssjj_dark", "heavy");
        ResourceLocation shootId = new ResourceLocation("ssjj_dark", "shoot");
        Object heavy = heavyId;
        Object shoot = shootId;
        if (modern) {
            heavy = soundType.getMethod("of", ResourceLocation.class).invoke(null, heavyId);
            var constructor = soundType.getDeclaredConstructor(ResourceLocation.class, Float.class,
                                                               Float.class, float.class, float.class);
            constructor.setAccessible(true);
            shoot = constructor.newInstance(shootId, 0.35f, 1.75f, 0.2f, 0.1f);
            check(soundType.getMethod("getVolume").invoke(shoot).equals(0.35f), "Configured volume fixture failed");
            check(soundType.getMethod("getPitch").invoke(shoot).equals(1.75f), "Configured pitch fixture failed");
            check(soundType.getMethod("getVolumeRandomRange").invoke(shoot).equals(0.2f), "Volume range fixture failed");
            check(soundType.getMethod("getPitchRandomRange").invoke(shoot).equals(0.1f), "Pitch range fixture failed");
            check(soundType.getMethod("getVolume").invoke(heavy) == null, "Default SoundData volume changed");
            check(soundType.getMethod("getPitch").invoke(heavy) == null, "Default SoundData pitch changed");
        }
        Map<String, Object> sounds = new HashMap<>();
        sounds.put("heavy", heavy);
        sounds.put("shoot", shoot);
        sounds.put("explicit_null", null);
        field(GunDisplayInstance.class, "sounds").set(display, sounds);
        check(lookup.invoke(null, display, "heavy") == heavy, "Heavy sound object identity changed");
        check(lookup.invoke(null, display, "shoot") == shoot, "Shoot sound object or metadata was flattened");
        check(lookup.invoke(null, display, "missing") == null, "Missing sound semantics changed");
        check(lookup.invoke(null, display, "explicit_null") == null, "Null sound semantics changed");
        check(sounds.size() == 3 && sounds.get("heavy") == heavy && sounds.get("shoot") == shoot,
              "Sound bridge mutated native display state");

        Map<String, Object> report = new LinkedHashMap<>();
        report.put("passed", true);
        report.put("runtime_sound_type", soundType.getName());
        report.put("runtime_sound_api", modern ? "TaCZ 1.2.0 SoundData" : "TaCZ 1.1.8 ResourceLocation");
        report.put("native_playback_overload", nativePlay.toGenericString());
        report.put("cached_handle_types", handleTypes);
        report.put("sound_identity_and_metadata_preserved", true);
        report.put("missing_and_null_preserved", true);
        report.put("patch_calls", checkPatchedCaller(Path.of(args[0])));
        report.put("jvm_verified_dark_client_methods", verifiedMethods.length);
        report.put("dark_client_initialized", false);
        report.put("assertions", assertions);
        report.put("actual_audio_playback", false);
        report.put("boundary", "Uses actual release GunDisplayInstance and SoundData objects; Unsafe bypasses model loading only. JVM links/verifies patched DarkClient methods without class initialization. Checks exact cached handle types, native overload availability and final bytecode call sites. Does not initialize sound or GL services, or execute audible playback.");
        Path reportPath = Path.of(args[1]);
        Files.createDirectories(reportPath.toAbsolutePath().getParent());
        Files.writeString(reportPath, new GsonBuilder().setPrettyPrinting().create().toJson(report));
        System.out.println("PASS TaCZ sound compatibility type=" + soundType.getSimpleName() + " assertions=" + assertions);
    }
}
