"""Package the exact minimal overlay, then audit the whole paired delivery.

Requires check_all.py first. Never writes the desktop project or game instance.
"""
from pathlib import Path
import hashlib
import json
import re
import tomllib
import zipfile
import runtime_toolchain as t

VERSION = "1.1.46"
MOD_NAME = "[SSJJRPG]生死狙击冒险枪包.jar"
PACK_NAME = "[SSJJRPG]生死狙击冒险枪包.zip"
REPLACED = {
    "cn/ssjjdimension/DimensionReloadProtection.class",
    "cn/ssjjdimension/DimensionScopes.class",
    "cn/ssjjdimension/client/DimensionMeshRenderer.class",
    "cn/ssjjdimension/client/DimensionParticleEffects.class",
    "ssjj/dark/DarkClient.class",
    "coremods/judgment_skill_key.js",
    "META-INF/coremods.json",
}
ADDED = {"cn/ssjjcompat/TaCZSounds.class", "cn/ssjjcompat/SkillInputCompat.class",
         "cn/ssjjcompat/WeaponAssetWarmup.class", "coremods/weapon_asset_warmup.js"}


def metadata(name):
    return name in {"META-INF/mods.toml", "META-INF/MANIFEST.MF", "gunpack.meta.json"} or name.endswith("/gunpack_info.json")


def update_metadata(name, content):
    if name == "META-INF/mods.toml":
        content = re.sub(rb'(?m)^(\s*version\s*=\s*")[^"]+(".*)$',
                         lambda m: m[1]+VERSION.encode()+m[2], content)
        content = content.replace(b'[1.1.8,1.1.9)', b'[1.1.8,1.3.0)')
        return content.replace(b'[1.1.8-hotfix2,1.2.0)', b'[1.1.8-hotfix2,1.3.0)')
    if name == "META-INF/MANIFEST.MF":
        return re.sub(rb'(?m)^(Implementation-Version: )[^\r\n]+',
                      lambda m: m[1]+VERSION.encode(), content)
    if name == "gunpack.meta.json" or name.endswith("/gunpack_info.json"):
        data = json.loads(content)
        data['version'] = VERSION
        if name == 'gunpack.meta.json':
            assert data['dependencies']['tacz'] in ('[1.1.8-hotfix2,1.2.0)', '[1.1.8-hotfix2,1.3.0)')
            data['dependencies']['tacz'] = '[1.1.8-hotfix2,1.3.0)'
        return (json.dumps(data, ensure_ascii=False, indent=2)+'\n').encode()
    return content


def contents(path):
    with zipfile.ZipFile(path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())), "Duplicate archive paths"
        assert archive.testzip() is None, "CRC failure"
        return {n: archive.read(n) for n in archive.namelist()}


def write_archive(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, content in sorted(data.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)


def main():
    # Fail closed on stale production/native-test evidence.
    (t.EVIDENCE/'package_manifest.json').unlink(missing_ok=True)
    build = json.loads((t.EVIDENCE/'runtime_toolchain_build.json').read_text('utf-8'))
    assert t.sha256(t.EVIDENCE/'dependencies.json') == build['dependency_manifest_sha256'], 'Dependency manifest changed after build'
    dependencies = json.loads((t.EVIDENCE/'dependencies.json').read_text('utf-8'))
    expected_baselines = {
        'mod.jar': '20055563f8972aa2488257214b7c439e06c18b5afead0126b42e3dd673f950ce',
        'gunpack.zip': '3ec428e35258f5eb101f85d03acf97cab8df6f0c425824f6706c1516daa123d1',
    }
    for filename, digest in expected_baselines.items():
        assert t.sha256(t.ROOT/'baseline'/filename) == digest, 'Frozen baseline changed: '+filename
        manifest_key = 'baseline_mod_sha256' if filename == 'mod.jar' else 'baseline_pack_sha256'
        assert dependencies[manifest_key] == digest, 'Build used a different baseline: '+filename
    assert t.sha256(t.BUILD/'runtime.jar') == build['runtime_sha256']
    for source, digest in build['production_source_sha256'].items():
        assert t.sha256(t.ROOT/source) == digest, 'Source changed after build: '+source
    gate = json.loads((t.EVIDENCE/'native_gate.json').read_text('utf-8'))
    assert gate['passed'] and gate['runtime_overlay_sha256'] == t.sha256(t.BUILD/'runtime.jar'), 'Stale native checks'
    assert gate['tacz_sha256'] == t.sha256(t.TACZ_JAR), 'Dependency changed after native checks'
    gate_inputs = [*sorted((t.ROOT/'src').rglob('*.java')), *sorted((t.ROOT/'qa').glob('*.java')),
                   *sorted((t.ROOT/'tools').glob('*.java')), t.ROOT/'scripts/check_all.py',
                   t.ROOT/'scripts/runtime_toolchain.py', *sorted((t.ROOT/'resources').rglob('*.js'))]
    assert gate['input_sha256'] == {p.relative_to(t.ROOT).as_posix(): t.sha256(p) for p in gate_inputs}, 'Input set changed after native checks'
    for label, digest in gate['reports_sha256'].items():
        assert t.sha256(t.EVIDENCE/f'check_{label}.json') == digest, 'Stale native report: '+label
    tools = t.compile_java(sorted((t.ROOT/'tools').glob('*.java')), t.BUILD/'tools', t.tool_classpath(), 'compile_package_tools')
    tool_cp = [tools, *t.tool_classpath()]
    patched = t.BUILD/'patched/ssjj/dark/DarkClient.class'
    t.run_java('PatchSounds', [t.ROOT/'baseline/mod.jar', patched, t.EVIDENCE/'sound_patch.json'], tool_cp, 'patch_sounds')
    overlay = contents(t.BUILD/'runtime.jar')
    for script in sorted((t.ROOT/'resources/coremods').glob('*.js')):
        overlay['coremods/'+script.name] = script.read_bytes()
    with zipfile.ZipFile(t.ROOT/'baseline/mod.jar') as baseline:
        coremods = json.loads(baseline.read('META-INF/coremods.json'))
    assert 'ssjj_weapon_asset_warmup' not in coremods
    coremods['ssjj_weapon_asset_warmup'] = 'coremods/weapon_asset_warmup.js'
    overlay['META-INF/coremods.json'] = (json.dumps(coremods, indent=2)+'\n').encode()
    overlay['ssjj/dark/DarkClient.class'] = patched.read_bytes()
    assert REPLACED | ADDED <= overlay.keys()
    artifacts = {}
    snapshots = {}
    for kind, source_name, folder, filename in (
            ('mod', 'mod.jar', 'mods', MOD_NAME), ('pack', 'gunpack.zip', 'tacz', PACK_NAME)):
        source = t.ROOT/'baseline'/source_name
        old = contents(source)
        new = {n: update_metadata(n, b) if metadata(n) else b for n,b in old.items()}
        if kind == 'mod':
            new.update({n: overlay[n] for n in REPLACED | ADDED})
        assert set(old) <= set(new)
        changed = {n for n in old if old[n] != new[n]}
        assert changed - {n for n in changed if metadata(n)} == (REPLACED if kind == 'mod' else set())
        assert set(new)-set(old) == (ADDED if kind == 'mod' else set())
        # Metadata may change version and exactly the two TaCZ bounds only.
        for name in old:
            if metadata(name):
                assert new[name] == update_metadata(name, old[name])
        if kind == 'mod':
            data = tomllib.loads(new['META-INF/mods.toml'].decode())
            assert all(m['version'] == VERSION for m in data['mods'])
            dependencies = [d for group in data['dependencies'].values() for d in group if d['modId'] == 'tacz']
            assert {d['versionRange'] for d in dependencies} == {'[1.1.8,1.3.0)', '[1.1.8-hotfix2,1.3.0)'}
        for name in new:
            if name == 'gunpack.meta.json' or name.endswith('/gunpack_info.json'):
                assert json.loads(new[name])['version'] == VERSION
        target = t.ROOT/'candidate'/folder/filename
        write_archive(target, new)
        assert contents(target) == new
        artifacts[kind] = {'path': str(target), 'sha256': t.sha256(target),
                           'baseline_sha256': t.sha256(source), 'changed': sorted(changed),
                           'added': sorted(set(new)-set(old)), 'unchanged_entries': len(old)-len(changed)}
        snapshots[kind] = new
    mod, pack = snapshots['mod'], snapshots['pack']
    shared = {n for n in pack.keys() & mod.keys() if n.startswith(('assets/', 'data/'))}
    assert all(pack[n] == mod[n] for n in shared), 'Paired shared resource mismatch'
    final_mod = Path(artifacts['mod']['path'])
    t.run_java('ApiContract', [t.ROOT/'baseline/mod.jar', final_mod, t.EVIDENCE/'public_api.json'], tool_cp, 'public_api')
    old_releases = sorted((t.INSTANCE/'mods').glob('*tacz-1.20.1-1.1.8-hotfix2.jar*'))
    assert len(old_releases) == 1, 'Expected exact original TaCZ for compatibility gate'
    sound_qa = t.compile_java([t.ROOT/'qa/TaCZSoundCompatCheck.java'], t.BUILD/'sound_qa',
                             t.runtime_classpath()+t.tool_classpath(), 'compile_sound_qa')
    for label, dependency in [('1.2.0', t.TACZ_JAR), ('1.1.8-hotfix2', old_releases[0])]:
        cp_file = t.path_list(t.BUILD/f'final_classpath_{label}.txt', t.runtime_classpath(dependency))
        t.run_java('FreshRuntimeLinks', [final_mod, cp_file, t.EVIDENCE/f'full_links_{label}.json'],
                   tool_cp, 'full_links_'+label)
        t.run_java('TaCZSoundCompatCheck', [final_mod, t.EVIDENCE/f'sound_compat_{label}.json'],
                   [sound_qa, final_mod, *t.runtime_classpath(dependency), *t.tool_classpath()],
                   'sound_compat_'+label)
    from check_loading import main as check_loading
    check_loading()
    from check_warmup import main as check_warmup
    check_warmup()
    t.save(t.EVIDENCE/'package_manifest.json', {'passed': True, 'version': VERSION, 'artifacts': artifacts,
        'shared_resources_checked': len(shared), 'public_api': 'unchanged for all existing 555 classes',
        'configuration_writes': 0, 'game_launched': False, 'full_historical_source_rebuild': False})
    print('PASS minimal pair delta, CRC, all shared resources, all public APIs, full old/new runtime links and actual loading gates')


if __name__ == '__main__':
    main()
