"""Build the declared Java overlay against the selected actual TaCZ release."""
import runtime_toolchain as t

if __name__ == "__main__":
    print(t.build_runtime())
