"""Explicit Java 17 build APIs for the frozen current delivery.

Dependencies are selected once. No dynamic import, game installation or launcher
invocation occurs. Set SSJJ_PROJECT, SSJJ_MC_HOME, SSJJ_JAVA_HOME or SSJJ_TACZ_JAR
when rebuilding on another machine; the frozen baseline pair must be supplied.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = Path(os.environ.get("SSJJ_PROJECT", "${SSJJ_PROJECT}"))
BUILD = ROOT / "build"
EVIDENCE = ROOT / "evidence"
JAVA_HOME = Path(os.environ.get("SSJJ_JAVA_HOME", "${SSJJ_JAVA_HOME}"))
JAVA = JAVA_HOME / "bin/java.exe"
JAVAC = JAVA_HOME / "bin/javac.exe"
MC_HOME = Path(os.environ.get("SSJJ_MC_HOME", "${SSJJ_MC_HOME}"))
INSTANCE = MC_HOME / "versions/1.20.1-Forge_47.4.28"
LIBRARIES = MC_HOME / "libraries"
GENERIC_API = PROJECT / "裁决之炎/work/addon_build"
TACZ_JAR = Path(os.environ.get("SSJJ_TACZ_JAR", "${SSJJ_TACZ_JAR}"))
NATIVE_DEPS = BUILD / "native_dependencies"
OFFICIAL_MAPPING = LIBRARIES / "net/minecraft/client/1.20.1-20230612.114412/client-1.20.1-20230612.114412-mappings.txt"
MERGED_MAPPING = LIBRARIES / "de/oceanlabs/mcp/mcp_config/1.20.1-20230612.114412/mcp_config-1.20.1-20230612.114412-mappings-merged.txt"


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def _unique(paths):
    return list(dict.fromkeys(Path(path).resolve() for path in paths))


def _version_libraries() -> list[Path]:
    metadata = json.loads((INSTANCE / "1.20.1-Forge_47.4.28.json").read_text("utf-8"))
    paths = []
    for library in metadata["libraries"]:
        rules = library.get("rules", [])
        allowed = not rules
        for rule in rules:
            system = rule.get("os", {})
            if system.get("name", "windows") != "windows":
                continue
            if "arch" in system and not re.search(system["arch"], platform.machine().lower()):
                continue
            if "version" in system and not re.search(system["version"], platform.version()):
                continue
            if rule.get("features"):
                continue
            allowed = rule["action"] == "allow"
        if not allowed:
            continue
        artifact = library.get("downloads", {}).get("artifact", {}).get("path")
        if artifact:
            path = LIBRARIES / artifact
            if not path.is_file():
                raise FileNotFoundError(path)
            paths.append(path)
    # Forge loads these four modules separately rather than listing them in
    # the launch JSON's ordinary libraries array.
    for module in ("fmlcore", "javafmllanguage", "mclanguage", "lowcodelanguage"):
        path = LIBRARIES / f"net/minecraftforge/{module}/1.20.1-47.4.28/{module}-1.20.1-47.4.28.jar"
        if not path.is_file():
            raise FileNotFoundError(path)
        paths.append(path)
    return _unique(paths)


def named_classpath() -> list[Path]:
    """Actual selected TaCZ and baseline named APIs, never historical renderer output."""
    named = [GENERIC_API / name for name in
             ("patched_mc-named.jar", "mc-named.jar", "forge-named.jar")]
    nested = json.loads((BUILD / "api/nested-classpath.json").read_text("utf-8"))
    assert nested["tacz_sha256"] == sha256(TACZ_JAR), "Named dependencies belong to another release"
    return _unique(named + [BUILD / "api/tacz-named.jar", BUILD / "api/baseline-named.jar"]
                   + [Path(p) for p in nested["paths"]] + _version_libraries())


def runtime_classpath(tacz=None) -> list[Path]:
    """Unmodified real runtime APIs; optional explicit release for compatibility audits."""
    forge = LIBRARIES / "net/minecraftforge/forge/1.20.1-47.4.28"
    release = Path(tacz or TACZ_JAR)
    nested = extract_nested(release, BUILD / "dependencies" / sha256(release)[:16])
    paths = [forge / "forge-1.20.1-47.4.28-client.jar",
             LIBRARIES / "net/minecraft/client/1.20.1-20230612.114412/client-1.20.1-20230612.114412-srg.jar",
             forge / "forge-1.20.1-47.4.28-universal.jar", release]
    paths += nested + list((INSTANCE / "mods").glob("*cloth*.jar"))
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
    return _unique(paths + _version_libraries())


def tool_classpath() -> list[Path]:
    asm = LIBRARIES / "org/ow2/asm"
    return [asm / f"{name}/9.9.1/{name}-9.9.1.jar" for name in ("asm", "asm-commons")] + [
        LIBRARIES / "net/minecraftforge/srgutils/0.5.6/srgutils-0.5.6.jar",
        LIBRARIES / "com/google/code/gson/gson/2.10/gson-2.10.jar",
    ]


def _argfile_argument(value) -> str:
    # Java argument files use backslash escapes inside quotes. Forward-slash
    # paths avoid accidental \t/\n, and JSON/shell quoting is never involved.
    return '"' + str(value).replace("\\", "/").replace('"', '\\"') + '"'


def _execute(executable: Path, arguments, label: str) -> str:
    logs = BUILD / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    path = logs / f"{label}.args"
    # JDK 17's Windows launcher reads @files using the Windows ANSI code page,
    # before -Dfile.encoding takes effect. Preserve Chinese dependency paths.
    argument_encoding = f"cp{ctypes.windll.kernel32.GetACP()}" if os.name == "nt" else "utf-8"
    path.write_text("\n".join(_argfile_argument(arg) for arg in arguments) + "\n", encoding=argument_encoding)
    result = subprocess.run([str(executable), "@" + str(path)], cwd=ROOT,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace")
    (logs / f"{label}.txt").write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"{label} failed ({result.returncode}):\n{result.stdout}")
    return result.stdout


def compile_java(sources, destination: Path, classpath=(), label="compile_java") -> Path:
    """Compile explicit new sources into a caller-owned directory."""
    sources = [Path(path).resolve() for path in sources]
    if not sources:
        raise ValueError("No Java sources")
    destination = Path(destination).resolve()
    destination.relative_to(BUILD.resolve())
    destination.parent.mkdir(parents=True, exist_ok=True)
    suffix = uuid.uuid4().hex[:8]
    staged = destination.with_name(destination.name + "_stage_" + suffix)
    staged.resolve().relative_to(BUILD.resolve())
    staged.mkdir()
    _execute(JAVAC, ["-J-Dfile.encoding=UTF-8", "-encoding", "UTF-8", "--release", "17", "-proc:none", "-cp",
                    os.pathsep.join(str(p) for p in classpath), "-d", staged, *sources], label)
    if destination.exists():
        previous = destination.with_name(destination.name + "_previous_" + suffix)
        previous.resolve().relative_to(BUILD.resolve())
        destination.rename(previous)
    staged.rename(destination)
    return destination


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def path_list(path, paths):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(str(p) for p in paths) + "\n", encoding="utf-8")
    return path


def extract_nested(jar, destination):
    """Extract recursive JarJar dependencies, checking duplicate filenames agree."""
    destination.mkdir(parents=True, exist_ok=True)
    seen = {}
    def visit(path):
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if name.startswith("META-INF/jarjar/") and name.endswith(".jar"):
                    content = archive.read(name)
                    target = destination / Path(name).name
                    if target.name in seen:
                        if seen[target.name] != content:
                            raise ValueError("Conflicting nested dependency " + target.name)
                        continue
                    seen[target.name] = content
                    target.write_bytes(content)
                    visit(target)
    visit(jar)
    return [destination / name for name in sorted(seen)]


def prepare_toolchain():
    """Prepare named APIs from the exact selected release and frozen delivery."""
    BUILD.mkdir(parents=True, exist_ok=True)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    for path in [JAVA, JAVAC, OFFICIAL_MAPPING, MERGED_MAPPING, TACZ_JAR,
                 ROOT / "baseline/mod.jar", ROOT / "baseline/gunpack.zip", *tool_classpath()]:
        if not path.is_file():
            raise FileNotFoundError(path)
    tools = compile_java(sorted((ROOT / "tools").glob("*.java")), BUILD / "tools", tool_classpath(), "compile_tools")
    nested = extract_nested(TACZ_JAR, BUILD / "dependencies" / sha256(TACZ_JAR)[:16])
    runtime = runtime_classpath()
    cp_file = path_list(BUILD / "runtime_classpath.txt", runtime + [ROOT / "baseline/mod.jar"])
    sources = [(TACZ_JAR, BUILD / "api/tacz-named.jar"),
               (ROOT / "baseline/mod.jar", BUILD / "api/baseline-named.jar")]
    named_nested = BUILD / "api/nested" / sha256(TACZ_JAR)[:16]
    sources += [(p, named_nested / p.name) for p in nested]
    remap_inputs = {str(p): sha256(p) for p in [OFFICIAL_MAPPING, MERGED_MAPPING,
        ROOT / "tools/PrepareNamed.java", ROOT / "tools/FreshRemap.java"]}
    for source, destination in sources:
        fingerprint = hashlib.sha256(json.dumps({"source": sha256(source),
            "mapping_and_tool_sha256": remap_inputs}, sort_keys=True).encode()).hexdigest()
        stamp = destination.with_suffix(".input.sha256")
        if destination.is_file() and stamp.is_file() and stamp.read_text() == fingerprint:
            continue
        run_java("PrepareNamed", [OFFICIAL_MAPPING, MERGED_MAPPING, source, destination,
                                  cp_file, EVIDENCE / ("named_" + destination.stem + ".json")],
                 [tools, *tool_classpath()], "named_" + destination.stem)
        stamp.write_text(fingerprint, encoding="ascii")
    save(BUILD / "api/nested-classpath.json", {"tacz_sha256": sha256(TACZ_JAR),
        "paths": [str(named_nested / p.name) for p in nested]})
    # Resource fixtures are byte copies from the current frozen gunpack.
    with zipfile.ZipFile(ROOT / "baseline/gunpack.zip") as archive:
        for name in archive.namelist():
            if not name.endswith("/") and name.startswith(("assets/", "data/")):
                target = ROOT / "pack" / name
                target.resolve().relative_to((ROOT / "pack").resolve())
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.is_file() or target.read_bytes() != archive.read(name):
                    target.write_bytes(archive.read(name))
    NATIVE_DEPS.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(TACZ_JAR) as archive:
        (NATIVE_DEPS / "official_default_state_machine.lua").write_bytes(archive.read(
            "assets/tacz/custom/tacz_default_gun/assets/tacz/scripts/default_state_machine.lua"))
    save(EVIDENCE / "dependencies.json", {"tacz": str(TACZ_JAR),
        "tacz_sha256": sha256(TACZ_JAR), "baseline_mod_sha256": sha256(ROOT / "baseline/mod.jar"),
        "baseline_pack_sha256": sha256(ROOT / "baseline/gunpack.zip"),
        "named_api_sha256": {str(p): sha256(p) for p in named_classpath() if p.suffix == ".jar"},
        "mapping_sha256": {str(p): sha256(p) for p in (OFFICIAL_MAPPING, MERGED_MAPPING)}})
    return tools


def compile_named(sources=None, destination=None, extra_classpath=(), label="production_compile"):
    return compile_java(sources or sorted((ROOT / "src").rglob("*.java")),
                        destination or BUILD / "named", named_classpath() + list(extra_classpath), label)


def run_java(main_class, args=(), classpath=(), label="run_java", jvm_args=()):
    return _execute(JAVA, ["-Dfile.encoding=UTF-8", *jvm_args, "-cp",
                          os.pathsep.join(str(p) for p in classpath), main_class, *args], label)


def build_runtime():
    tools = prepare_toolchain()
    production = sorted((ROOT / "src").rglob("*.java"))
    hashes = {p.relative_to(ROOT).as_posix(): sha256(p) for p in production}
    named = compile_named(production)
    assert hashes == {p.relative_to(ROOT).as_posix(): sha256(p) for p in production}, "Source changed during compilation"
    named_cp = path_list(BUILD / "named_classpath.txt", named_classpath())
    runtime = BUILD / "runtime.jar"
    run_java("FreshRemap", [OFFICIAL_MAPPING, MERGED_MAPPING, named, runtime,
                            named_cp, EVIDENCE / "runtime_remap.json"],
             [tools, *tool_classpath()], "remap_production")
    save(EVIDENCE / "runtime_toolchain_build.json", {"runtime_sha256": sha256(runtime),
        "production_source_sha256": hashes,
        "production_named_classes_sha256": {p.relative_to(named).as_posix(): sha256(p) for p in sorted(named.rglob("*.class"))},
        "dependency_manifest_sha256": sha256(EVIDENCE / "dependencies.json"),
        "full_historical_source_rebuild": False, "live_client_test": False})
    return runtime
