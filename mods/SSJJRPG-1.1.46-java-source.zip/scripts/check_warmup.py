"""Prove native weapon model/runtime cold work finishes before first-use getters."""
import json
import shutil
import zipfile
import runtime_toolchain as t

def main():
    gate=t.EVIDENCE/'warmup_gate.json'
    gate.unlink(missing_ok=True)
    mod=t.ROOT/'candidate/mods/[SSJJRPG]生死狙击冒险枪包.jar'
    pack=t.ROOT/'candidate/tacz/[SSJJRPG]生死狙击冒险枪包.zip'
    with zipfile.ZipFile(mod) as candidate,zipfile.ZipFile(t.BUILD/'runtime.jar') as runtime:
        name='cn/ssjjcompat/WeaponAssetWarmup.class'
        assert candidate.read(name)==runtime.read(name),'Final warmup class differs from current build'
    old=list((t.INSTANCE/'mods').glob('*tacz-1.20.1-1.1.8-hotfix2.jar*'))
    assert len(old)==1
    qa=t.compile_java([t.ROOT/'qa/WeaponWarmupCheck.java'],t.BUILD/'warmup_qa',t.runtime_classpath(),'compile_warmup_qa')
    reports={}
    for version,dependency in [('1.2.0',t.TACZ_JAR),('1.1.8-hotfix2',old[0])]:
        assets=t.BUILD/'warmup_assets'/version
        assets.resolve().relative_to((t.BUILD/'warmup_assets').resolve())
        if assets.exists():shutil.rmtree(assets)
        # First official defaults, then the actual candidate pair: same override order as installation.
        for archive in (dependency,mod,pack):
            with zipfile.ZipFile(archive) as source:
                for name in source.namelist():
                    original=name
                    prefix='assets/tacz/custom/tacz_default_gun/'
                    if name.startswith(prefix):name=name[len(prefix):]
                    selected=name.startswith(('assets/tacz/animations/','assets/tacz/geo_models/','assets/tacz/scripts/','assets/tacz/ads_presets/')) and name.endswith(('.json','.lua'))
                    selected |= name.startswith(('assets/judgfire/','assets/ssjj_dark/')) and name.endswith(('.json','.lua','.png'))
                    if not selected:continue
                    destination=assets/name
                    destination.parent.mkdir(parents=True,exist_ok=True)
                    destination.write_bytes(source.read(original))
        report=t.EVIDENCE/f'warmup_{version}.json'
        print(t.run_java('WeaponWarmupCheck',[assets,version,report],[qa,*t.runtime_classpath(dependency),mod],
            'warmup_'+version).strip(),flush=True)
        assert json.loads(report.read_text('utf-8'))['passed']
        reports[version]=t.sha256(report)
    t.save(gate,{'passed':True,'mod_sha256':t.sha256(mod),'pack_sha256':t.sha256(pack),'reports_sha256':reports,
        'source_sha256':{p.relative_to(t.ROOT).as_posix():t.sha256(p) for p in [t.ROOT/'src/cn/ssjjcompat/WeaponAssetWarmup.java',t.ROOT/'qa/WeaponWarmupCheck.java',t.ROOT/'scripts/check_warmup.py']}})

if __name__=='__main__':main()
