"""Exercise actual coremod transformers and actual TaCZ gunpack admission before accepting a pair."""
import json
import runtime_toolchain as t

def main():
    mod=t.ROOT/'candidate/mods/[SSJJRPG]生死狙击冒险枪包.jar'
    pack=t.ROOT/'candidate/tacz/[SSJJRPG]生死狙击冒险枪包.zip'
    asm=[t.LIBRARIES/f'org/ow2/asm/{name}/9.9.1/{name}-9.9.1.jar'for name in ('asm','asm-tree','asm-analysis','asm-commons')]
    nashorn=t.LIBRARIES/'org/openjdk/nashorn/nashorn-core/15.4/nashorn-core-15.4.jar'
    tools=[*asm,nashorn]
    qa=t.compile_java([t.ROOT/'qa/LoadingCoremodCheck.java'],t.BUILD/'loading_qa',[*tools,*t.runtime_classpath()],'compile_loading_qa')
    old=list((t.INSTANCE/'mods').glob('*tacz-1.20.1-1.1.8-hotfix2.jar*'))
    assert len(old)==1
    results={}
    for version,dependency in [('1.2.0',t.TACZ_JAR),('1.1.8-hotfix2',old[0])]:
        report=t.EVIDENCE/f'loading_{version}.json'
        print(t.run_java('LoadingCoremodCheck',[mod,dependency,pack,t.ROOT/'baseline/gunpack.zip',version,report],
            [qa,*tools,*t.runtime_classpath(dependency),mod],'loading_'+version).strip(),flush=True)
        assert json.loads(report.read_text('utf-8'))['passed']
        results[version]=t.sha256(report)
    t.save(t.EVIDENCE/'loading_gate.json',{'passed':True,'mod_sha256':t.sha256(mod),'pack_sha256':t.sha256(pack),
        'reports_sha256':results,'source_sha256':{str(p.relative_to(t.ROOT)):t.sha256(p)for p in [t.ROOT/'qa/LoadingCoremodCheck.java',t.ROOT/'scripts/check_loading.py']}})
if __name__=='__main__':main()
