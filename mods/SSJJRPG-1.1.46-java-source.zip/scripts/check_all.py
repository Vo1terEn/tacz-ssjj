"""Complete current editable-scope gate; no client, installation or GL launch.

Build the overlay and execute the existing Java family/input/FOV/skin/glint
behavior assertions with their API fixtures adapted to the actual release.
Final frozen-delivery packaging/link/API verification follows in package_pair.
"""
import json
import shutil
import zipfile

import runtime_toolchain as t


def main():
    inputs = [*sorted((t.ROOT / "src").rglob("*.java")), *sorted((t.ROOT / "qa").glob("*.java")),
              *sorted((t.ROOT / "tools").glob("*.java")), t.ROOT / "scripts/check_all.py",
              t.ROOT / "scripts/runtime_toolchain.py", *sorted((t.ROOT / "resources").rglob("*.js"))]
    before = {p.relative_to(t.ROOT).as_posix(): t.sha256(p) for p in inputs}
    gate = t.EVIDENCE / "native_gate.json"
    if gate.exists():
        gate.unlink()
    t.build_runtime()
    dependency_hash = t.sha256(t.EVIDENCE / "dependencies.json")
    # Forge extends KeyMapping constructors. Select its real patched class even
    # when the unpatched named MC JAR otherwise precedes the patched API for QA.
    selected = t.BUILD / "native_input_api.jar"
    with zipfile.ZipFile(t.GENERIC_API / "patched_mc-named.jar") as source, zipfile.ZipFile(selected, "w") as target:
        for name in source.namelist():
            if name == "net/minecraft/client/KeyMapping.class" or name.startswith("net/minecraft/client/KeyMapping$"):
                target.writestr(name, source.read(name))
    sources = sorted((t.ROOT / "qa").glob("Dimension*.java"))
    cp = [t.BUILD / "named", selected, *t.named_classpath()]
    classes = t.compile_java(sources, t.BUILD / "qa", cp, "compile_native_qa")
    runtime = t._unique([selected, t.GENERIC_API / "mc-named.jar", classes, *cp,
                         t.INSTANCE / "1.20.1-Forge_47.4.28.jar"])
    # The original glint regression verifies the six repairs from the previous
    # round using that exact pre-repair archive, not today's already-fixed pair.
    historical = t.PROJECT / "work/dimension_skin_fix_20261107/baseline/tacz/[SSJJRPG]生死狙击冒险枪包.zip"
    fixture = t.ROOT / "baseline/tacz/[SSJJRPG]生死狙击冒险枪包.zip"
    fixture.parent.mkdir(parents=True, exist_ok=True)
    if not fixture.is_file() or t.sha256(fixture) != t.sha256(historical):
        shutil.copyfile(historical, fixture)
    t.save(t.EVIDENCE / "qa_fixtures.json", {"glint_pre_repair_source": str(historical),
        "glint_pre_repair_sha256": t.sha256(fixture), "behavior_assertions_weakened": False,
        "fixture_api_adapted": True})
    commands = [("DimensionFamilyCheck", [t.ROOT], "family")]
    for gun in ("dimension_star", "dimension_star1", "dimension_star2"):
        commands += [("DimensionInputCheck", [t.ROOT, "ssjj_dimension:" + gun], "input_" + gun),
                     ("DimensionFovCheck", [t.ROOT, "ssjj_dimension:" + gun], "fov_" + gun)]
    commands += [("DimensionSkinSwitchCheck", [t.ROOT], "skin_switch"),
                 ("DimensionGlintCheck", [t.ROOT], "glints")]
    reports = {}
    for main_class, args, label in commands:
        print(t.run_java(main_class, args, runtime, "qa_" + label).strip(), flush=True)
        source = {"DimensionFamilyCheck": "family_native.json", "DimensionInputCheck": "input_native.json",
                  "DimensionFovCheck": "fov_event_check.json", "DimensionSkinSwitchCheck": "skin_switch_native.json",
                  "DimensionGlintCheck": "glint_native.json"}[main_class]
        data = json.loads((t.EVIDENCE / source).read_text("utf-8"))
        assert data["passed"], label
        destination = t.EVIDENCE / ("check_" + label + ".json")
        t.save(destination, data)
        reports[label] = t.sha256(destination)
    assert before == {p.relative_to(t.ROOT).as_posix(): t.sha256(p) for p in inputs}, "Gate sources changed during validation"
    assert dependency_hash == t.sha256(t.EVIDENCE / "dependencies.json"), "Gate dependencies changed during validation"
    t.save(gate, {"passed": True,
        "tacz_sha256": t.sha256(t.TACZ_JAR), "runtime_overlay_sha256": t.sha256(t.BUILD / "runtime.jar"),
        "reports_sha256": reports, "behavior_assertions_weakened": False, "fixture_api_adapted": True,
        "input_sha256": before, "dependency_manifest_sha256": dependency_hash,
        "live_client_test": False, "boundary": "Standalone native API hosts; no physical input, GL, full client or server networking."})
    print("PASS complete native regression gate: " + str(len(commands)) + " runs")


if __name__ == "__main__":
    main()
